<?php
require_once(__DIR__."/shopiro-client/src/Init.php");