<?php
$country_blocks=array();