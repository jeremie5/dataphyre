<?php
 $date_locale=array (
  'si' => 
  array (
    'abstract' => 
    array (
      'today' => 'අද',
      'yesterday' => 'ඊයේ',
      'two days ago' => 'දවස් දෙකකට කලින්',
      'in two days' => 'දින දෙකකින්',
      'last week' => 'ගිය සතිය',
      'last month' => 'පසුගිය මාසයේ',
      'last year' => 'පසුගිය වසර',
      'last decade' => 'පසුගිය දශකය',
      'last century' => 'පසුගිය සියවස',
      'last millennial' => 'පසුගිය සහස්රයේ',
      'at' => 'හිදී',
      'of' => 'වල',
      'am' => 'පෙ.ව.',
      'pm' => 'ප.ව.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'ජනවාරි',
        1 => 'ජන',
      ),
      'february' => 
      array (
        0 => 'පෙබරවාරි',
        1 => 'පෙබ',
      ),
      'march' => 
      array (
        0 => 'මාර්තු',
        1 => 'මාර්තු',
      ),
      'april' => 
      array (
        0 => 'අප්‍රේල්',
        1 => 'අප්‍රේල්',
      ),
      'may' => 
      array (
        0 => 'මැයි',
        1 => 'මැයි',
      ),
      'june' => 
      array (
        0 => 'ජූනි',
        1 => 'ජූනි',
      ),
      'july' => 
      array (
        0 => 'ජූලි',
        1 => 'ජූලි',
      ),
      'august' => 
      array (
        0 => 'අගෝස්තු',
        1 => 'අගෝ',
      ),
      'september' => 
      array (
        0 => 'සැප්තැම්බර්',
        1 => 'සැප්',
      ),
      'october' => 
      array (
        0 => 'ඔක්තෝබර්',
        1 => 'ඔක්',
      ),
      'november' => 
      array (
        0 => 'නොවැම්බර්',
        1 => 'නොවැ',
      ),
      'december' => 
      array (
        0 => 'දෙසැම්බර්',
        1 => 'දෙසැ',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'ඉරිදා',
        1 => 'ඉරිදා',
      ),
      'monday' => 
      array (
        0 => 'සඳුදා',
        1 => 'සඳුදා',
      ),
      'tuesday' => 
      array (
        0 => 'අඟහරුවාදා',
        1 => 'අඟහ',
      ),
      'wednesday' => 
      array (
        0 => 'බදාදා',
        1 => 'බදාදා',
      ),
      'friday' => 
      array (
        0 => 'සිකුරාදා',
        1 => 'සිකු',
      ),
      'thursday' => 
      array (
        0 => 'බ්‍රහස්පතින්දා',
        1 => 'බ්‍රහස්',
      ),
      'saturday' => 
      array (
        0 => 'සෙනසුරාදා',
        1 => 'සෙන',
      ),
    ),
  ),
);