<?php
 $date_locale=array (
  'fy' => 
  array (
    'abstract' => 
    array (
      'today' => 'hjoed',
      'yesterday' => 'juster',
      'two days ago' => 'twa dagen lyn',
      'in two days' => 'oer twa dagen',
      'last week' => 'ferline wike',
      'last month' => 'ferline moanne',
      'last year' => 'ôfrûne jier',
      'last decade' => 'lêste desennia',
      'last century' => 'foarige ieu',
      'last millennial' => 'lêste millennium',
      'at' => 'by',
      'of' => 'fan',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Jannewaris',
        1 => 'Jan',
      ),
      'february' => 
      array (
        0 => 'Febrewaris',
        1 => 'Feb',
      ),
      'march' => 
      array (
        0 => 'Maart',
        1 => 'Mrt',
      ),
      'april' => 
      array (
        0 => 'April',
        1 => 'Apr',
      ),
      'may' => 
      array (
        0 => 'Maaie',
        1 => 'Mai',
      ),
      'june' => 
      array (
        0 => 'Juny',
        1 => 'Jun',
      ),
      'july' => 
      array (
        0 => 'July',
        1 => 'Jul',
      ),
      'august' => 
      array (
        0 => 'Augustus',
        1 => 'Aug',
      ),
      'september' => 
      array (
        0 => 'Septimber',
        1 => 'Sep',
      ),
      'october' => 
      array (
        0 => 'Oktober',
        1 => 'Okt',
      ),
      'november' => 
      array (
        0 => 'Novimber',
        1 => 'Nov',
      ),
      'december' => 
      array (
        0 => 'Desimber',
        1 => 'Des',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'snein',
        1 => 'si',
      ),
      'monday' => 
      array (
        0 => 'moandei',
        1 => 'mo',
      ),
      'tuesday' => 
      array (
        0 => 'tiisdei',
        1 => 'ti',
      ),
      'wednesday' => 
      array (
        0 => 'woansdei',
        1 => 'wo',
      ),
      'friday' => 
      array (
        0 => 'freed',
        1 => 'fr',
      ),
      'thursday' => 
      array (
        0 => 'tongersdei',
        1 => 'to',
      ),
      'saturday' => 
      array (
        0 => 'sneon',
        1 => 'so',
      ),
    ),
  ),
);