<?php
 $date_locale=array (
  'it-CH' => 
  array (
    'abstract' => 
    array (
      'today' => 'oggi',
      'yesterday' => 'ieri',
      'two days ago' => 'due giorni fa',
      'in two days' => 'in due giorni',
      'last week' => 'la scorsa settimana',
      'last month' => 'lo scorso mese',
      'last year' => 'l&#39;anno scorso',
      'last decade' => 'ultimo decennio',
      'last century' => 'l&#39;ultimo secolo',
      'last millennial' => 'ultimo millenario',
      'at' => 'in',
      'of' => 'di',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'gennaio',
        1 => 'gen',
      ),
      'february' => 
      array (
        0 => 'febbraio',
        1 => 'feb',
      ),
      'march' => 
      array (
        0 => 'marzo',
        1 => 'mar',
      ),
      'april' => 
      array (
        0 => 'aprile',
        1 => 'apr',
      ),
      'may' => 
      array (
        0 => 'maggio',
        1 => 'mag',
      ),
      'june' => 
      array (
        0 => 'giugno',
        1 => 'giu',
      ),
      'july' => 
      array (
        0 => 'luglio',
        1 => 'lug',
      ),
      'august' => 
      array (
        0 => 'agosto',
        1 => 'ago',
      ),
      'september' => 
      array (
        0 => 'settembre',
        1 => 'set',
      ),
      'october' => 
      array (
        0 => 'ottobre',
        1 => 'ott',
      ),
      'november' => 
      array (
        0 => 'novembre',
        1 => 'nov',
      ),
      'december' => 
      array (
        0 => 'dicembre',
        1 => 'dic',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'domenica',
        1 => 'dom',
      ),
      'monday' => 
      array (
        0 => 'lunedì',
        1 => 'lun',
      ),
      'tuesday' => 
      array (
        0 => 'martedì',
        1 => 'mar',
      ),
      'wednesday' => 
      array (
        0 => 'mercoledì',
        1 => 'mer',
      ),
      'friday' => 
      array (
        0 => 'venerdì',
        1 => 'ven',
      ),
      'thursday' => 
      array (
        0 => 'giovedì',
        1 => 'gio',
      ),
      'saturday' => 
      array (
        0 => 'sabato',
        1 => 'sab',
      ),
    ),
  ),
);