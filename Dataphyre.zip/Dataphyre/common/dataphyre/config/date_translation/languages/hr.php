<?php
 $date_locale=array (
  'hr' => 
  array (
    'abstract' => 
    array (
      'today' => 'danas',
      'yesterday' => 'jučer',
      'two days ago' => 'prije dva dana',
      'in two days' => 'za dva dana',
      'last week' => 'prošli tjedan',
      'last month' => 'prošli mjesec',
      'last year' => 'prošle godine',
      'last decade' => 'posljednje desetljeće',
      'last century' => 'posljednje stoljeće',
      'last millennial' => 'posljednje tisućljeće',
      'at' => 'na',
      'of' => 'od',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'siječnja',
        1 => 'sij',
      ),
      'february' => 
      array (
        0 => 'veljače',
        1 => 'velj',
      ),
      'march' => 
      array (
        0 => 'ožujka',
        1 => 'ožu',
      ),
      'april' => 
      array (
        0 => 'travnja',
        1 => 'tra',
      ),
      'may' => 
      array (
        0 => 'svibnja',
        1 => 'svi',
      ),
      'june' => 
      array (
        0 => 'lipnja',
        1 => 'lip',
      ),
      'july' => 
      array (
        0 => 'srpnja',
        1 => 'srp',
      ),
      'august' => 
      array (
        0 => 'kolovoza',
        1 => 'kol',
      ),
      'september' => 
      array (
        0 => 'rujna',
        1 => 'ruj',
      ),
      'october' => 
      array (
        0 => 'listopada',
        1 => 'lis',
      ),
      'november' => 
      array (
        0 => 'studenoga',
        1 => 'stu',
      ),
      'december' => 
      array (
        0 => 'prosinca',
        1 => 'pro',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'nedjelja',
        1 => 'ned',
      ),
      'monday' => 
      array (
        0 => 'ponedjeljak',
        1 => 'pon',
      ),
      'tuesday' => 
      array (
        0 => 'utorak',
        1 => 'uto',
      ),
      'wednesday' => 
      array (
        0 => 'srijeda',
        1 => 'sri',
      ),
      'friday' => 
      array (
        0 => 'petak',
        1 => 'pet',
      ),
      'thursday' => 
      array (
        0 => 'četvrtak',
        1 => 'čet',
      ),
      'saturday' => 
      array (
        0 => 'subota',
        1 => 'sub',
      ),
    ),
  ),
);