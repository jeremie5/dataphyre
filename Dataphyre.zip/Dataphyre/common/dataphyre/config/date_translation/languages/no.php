<?php
 $date_locale=array (
  'no' => 
  array (
    'abstract' => 
    array (
      'today' => 'i dag',
      'yesterday' => 'i går',
      'two days ago' => 'for to dager siden',
      'in two days' => 'om to dager',
      'last week' => 'forrige uke',
      'last month' => 'forrige måned',
      'last year' => 'i fjor',
      'last decade' => 'siste tiåret',
      'last century' => 'siste århundre',
      'last millennial' => 'siste årtusen',
      'at' => 'på',
      'of' => 'av',
      'am' => 'a.m.',
      'pm' => 'p.m.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'januar',
        1 => 'jan.',
      ),
      'february' => 
      array (
        0 => 'februar',
        1 => 'feb.',
      ),
      'march' => 
      array (
        0 => 'mars',
        1 => 'mar.',
      ),
      'april' => 
      array (
        0 => 'april',
        1 => 'apr.',
      ),
      'may' => 
      array (
        0 => 'mai',
        1 => 'mai',
      ),
      'june' => 
      array (
        0 => 'juni',
        1 => 'jun.',
      ),
      'july' => 
      array (
        0 => 'juli',
        1 => 'jul.',
      ),
      'august' => 
      array (
        0 => 'august',
        1 => 'aug.',
      ),
      'september' => 
      array (
        0 => 'september',
        1 => 'sep.',
      ),
      'october' => 
      array (
        0 => 'oktober',
        1 => 'okt.',
      ),
      'november' => 
      array (
        0 => 'november',
        1 => 'nov.',
      ),
      'december' => 
      array (
        0 => 'desember',
        1 => 'des.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'søndag',
        1 => 'søn.',
      ),
      'monday' => 
      array (
        0 => 'mandag',
        1 => 'man.',
      ),
      'tuesday' => 
      array (
        0 => 'tirsdag',
        1 => 'tir.',
      ),
      'wednesday' => 
      array (
        0 => 'onsdag',
        1 => 'ons.',
      ),
      'friday' => 
      array (
        0 => 'fredag',
        1 => 'fre.',
      ),
      'thursday' => 
      array (
        0 => 'torsdag',
        1 => 'tor.',
      ),
      'saturday' => 
      array (
        0 => 'lørdag',
        1 => 'lør.',
      ),
    ),
  ),
);