<?php
 $date_locale=array (
  'es-ES' => 
  array (
    'abstract' => 
    array (
      'today' => 'hoy',
      'yesterday' => 'ayer',
      'two days ago' => 'hace dos días',
      'in two days' => 'en dos días',
      'last week' => 'la semana pasada',
      'last month' => 'el mes pasado',
      'last year' => 'el año pasado',
      'last decade' => 'la última década',
      'last century' => 'el siglo pasado',
      'last millennial' => 'último milenio',
      'at' => 'a',
      'of' => 'de',
      'am' => 'a. m.',
      'pm' => 'p. m.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'enero',
        1 => 'ene.',
      ),
      'february' => 
      array (
        0 => 'febrero',
        1 => 'feb.',
      ),
      'march' => 
      array (
        0 => 'marzo',
        1 => 'mar.',
      ),
      'april' => 
      array (
        0 => 'abril',
        1 => 'abr.',
      ),
      'may' => 
      array (
        0 => 'mayo',
        1 => 'may.',
      ),
      'june' => 
      array (
        0 => 'junio',
        1 => 'jun.',
      ),
      'july' => 
      array (
        0 => 'julio',
        1 => 'jul.',
      ),
      'august' => 
      array (
        0 => 'agosto',
        1 => 'ago.',
      ),
      'september' => 
      array (
        0 => 'septiembre',
        1 => 'sept.',
      ),
      'october' => 
      array (
        0 => 'octubre',
        1 => 'oct.',
      ),
      'november' => 
      array (
        0 => 'noviembre',
        1 => 'nov.',
      ),
      'december' => 
      array (
        0 => 'diciembre',
        1 => 'dic.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'domingo',
        1 => 'dom.',
      ),
      'monday' => 
      array (
        0 => 'lunes',
        1 => 'lun.',
      ),
      'tuesday' => 
      array (
        0 => 'martes',
        1 => 'mar.',
      ),
      'wednesday' => 
      array (
        0 => 'miércoles',
        1 => 'mié.',
      ),
      'friday' => 
      array (
        0 => 'viernes',
        1 => 'vie.',
      ),
      'thursday' => 
      array (
        0 => 'jueves',
        1 => 'jue.',
      ),
      'saturday' => 
      array (
        0 => 'sábado',
        1 => 'sáb.',
      ),
    ),
  ),
);