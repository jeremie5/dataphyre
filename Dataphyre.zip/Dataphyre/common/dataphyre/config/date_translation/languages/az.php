<?php
 $date_locale=array (
  'az' => 
  array (
    'abstract' => 
    array (
      'today' => 'bu gün',
      'yesterday' => 'dünən',
      'two days ago' => 'İki gün əvvəl',
      'in two days' => 'iki gündə',
      'last week' => 'keçən həftə',
      'last month' => 'keçən ay',
      'last year' => 'keçən il',
      'last decade' => 'son onillik',
      'last century' => 'keçən əsr',
      'last millennial' => 'son minillik',
      'at' => 'saat',
      'of' => 'of',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'yanvar',
        1 => 'yan',
      ),
      'february' => 
      array (
        0 => 'fevral',
        1 => 'fev',
      ),
      'march' => 
      array (
        0 => 'mart',
        1 => 'mar',
      ),
      'april' => 
      array (
        0 => 'aprel',
        1 => 'apr',
      ),
      'may' => 
      array (
        0 => 'may',
        1 => 'may',
      ),
      'june' => 
      array (
        0 => 'iyun',
        1 => 'iyn',
      ),
      'july' => 
      array (
        0 => 'iyul',
        1 => 'iyl',
      ),
      'august' => 
      array (
        0 => 'avqust',
        1 => 'avq',
      ),
      'september' => 
      array (
        0 => 'sentyabr',
        1 => 'sen',
      ),
      'october' => 
      array (
        0 => 'oktyabr',
        1 => 'okt',
      ),
      'november' => 
      array (
        0 => 'noyabr',
        1 => 'noy',
      ),
      'december' => 
      array (
        0 => 'dekabr',
        1 => 'dek',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'bazar',
        1 => 'B.',
      ),
      'monday' => 
      array (
        0 => 'bazar ertəsi',
        1 => 'B.E.',
      ),
      'tuesday' => 
      array (
        0 => 'çərşənbə axşamı',
        1 => 'Ç.A.',
      ),
      'wednesday' => 
      array (
        0 => 'çərşənbə',
        1 => 'Ç.',
      ),
      'friday' => 
      array (
        0 => 'cümə',
        1 => 'C.',
      ),
      'thursday' => 
      array (
        0 => 'cümə axşamı',
        1 => 'C.A.',
      ),
      'saturday' => 
      array (
        0 => 'şənbə',
        1 => 'Ş.',
      ),
    ),
  ),
);