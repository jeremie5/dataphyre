<?php
 $date_locale=array (
  'hu' => 
  array (
    'abstract' => 
    array (
      'today' => 'ma',
      'yesterday' => 'tegnap',
      'two days ago' => 'két napja',
      'in two days' => 'két napon belül',
      'last week' => 'múlt hét',
      'last month' => 'múlt hónap',
      'last year' => 'tavaly',
      'last decade' => 'elmúlt évtizedben',
      'last century' => 'múlt század',
      'last millennial' => 'múlt évezredes',
      'at' => 'nál nél',
      'of' => 'nak,-nek',
      'am' => 'de.',
      'pm' => 'du.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'január',
        1 => 'jan.',
      ),
      'february' => 
      array (
        0 => 'február',
        1 => 'febr.',
      ),
      'march' => 
      array (
        0 => 'március',
        1 => 'márc.',
      ),
      'april' => 
      array (
        0 => 'április',
        1 => 'ápr.',
      ),
      'may' => 
      array (
        0 => 'május',
        1 => 'máj.',
      ),
      'june' => 
      array (
        0 => 'június',
        1 => 'jún.',
      ),
      'july' => 
      array (
        0 => 'július',
        1 => 'júl.',
      ),
      'august' => 
      array (
        0 => 'augusztus',
        1 => 'aug.',
      ),
      'september' => 
      array (
        0 => 'szeptember',
        1 => 'szept.',
      ),
      'october' => 
      array (
        0 => 'október',
        1 => 'okt.',
      ),
      'november' => 
      array (
        0 => 'november',
        1 => 'nov.',
      ),
      'december' => 
      array (
        0 => 'december',
        1 => 'dec.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'vasárnap',
        1 => 'V',
      ),
      'monday' => 
      array (
        0 => 'hétfő',
        1 => 'H',
      ),
      'tuesday' => 
      array (
        0 => 'kedd',
        1 => 'K',
      ),
      'wednesday' => 
      array (
        0 => 'szerda',
        1 => 'Sze',
      ),
      'friday' => 
      array (
        0 => 'péntek',
        1 => 'P',
      ),
      'thursday' => 
      array (
        0 => 'csütörtök',
        1 => 'Cs',
      ),
      'saturday' => 
      array (
        0 => 'szombat',
        1 => 'Szo',
      ),
    ),
  ),
);