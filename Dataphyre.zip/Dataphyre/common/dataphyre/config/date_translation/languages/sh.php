<?php
 $date_locale=array (
  'sh' => 
  array (
    'abstract' => 
    array (
      'today' => 'данас',
      'yesterday' => 'јуче',
      'two days ago' => 'Пре два дана',
      'in two days' => 'за два дана',
      'last week' => 'Прошле недеље',
      'last month' => 'прошлог месеца',
      'last year' => 'прошле године',
      'last decade' => 'Последња деценија',
      'last century' => 'прошлог века',
      'last millennial' => 'прошлог миленијума',
      'at' => 'ат',
      'of' => 'оф',
      'am' => 'pre podne',
      'pm' => 'po podne',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'januar',
        1 => 'jan',
      ),
      'february' => 
      array (
        0 => 'februar',
        1 => 'feb',
      ),
      'march' => 
      array (
        0 => 'mart',
        1 => 'mar',
      ),
      'april' => 
      array (
        0 => 'april',
        1 => 'apr',
      ),
      'may' => 
      array (
        0 => 'maj',
        1 => 'maj',
      ),
      'june' => 
      array (
        0 => 'jun',
        1 => 'jun',
      ),
      'july' => 
      array (
        0 => 'jul',
        1 => 'jul',
      ),
      'august' => 
      array (
        0 => 'avgust',
        1 => 'avg',
      ),
      'september' => 
      array (
        0 => 'septembar',
        1 => 'sep',
      ),
      'october' => 
      array (
        0 => 'oktobar',
        1 => 'okt',
      ),
      'november' => 
      array (
        0 => 'novembar',
        1 => 'nov',
      ),
      'december' => 
      array (
        0 => 'decembar',
        1 => 'dec',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'nedelja',
        1 => 'ned',
      ),
      'monday' => 
      array (
        0 => 'ponedeljak',
        1 => 'pon',
      ),
      'tuesday' => 
      array (
        0 => 'utorak',
        1 => 'uto',
      ),
      'wednesday' => 
      array (
        0 => 'sreda',
        1 => 'sre',
      ),
      'friday' => 
      array (
        0 => 'petak',
        1 => 'pet',
      ),
      'thursday' => 
      array (
        0 => 'četvrtak',
        1 => 'čet',
      ),
      'saturday' => 
      array (
        0 => 'subota',
        1 => 'sub',
      ),
    ),
  ),
);