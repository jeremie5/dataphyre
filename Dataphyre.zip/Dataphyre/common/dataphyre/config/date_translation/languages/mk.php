<?php
 $date_locale=array (
  'mk' => 
  array (
    'abstract' => 
    array (
      'today' => 'денес',
      'yesterday' => 'вчера',
      'two days ago' => 'пред два дена',
      'in two days' => 'за два дена',
      'last week' => 'минатата недела',
      'last month' => 'претходниот месец',
      'last year' => 'минатата година',
      'last decade' => 'минатата деценија',
      'last century' => 'минатиот век',
      'last millennial' => 'минатиот милениум',
      'at' => 'на',
      'of' => 'на',
      'am' => 'претпладне',
      'pm' => 'попладне',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'јануари',
        1 => 'јан.',
      ),
      'february' => 
      array (
        0 => 'февруари',
        1 => 'фев.',
      ),
      'march' => 
      array (
        0 => 'март',
        1 => 'мар.',
      ),
      'april' => 
      array (
        0 => 'април',
        1 => 'апр.',
      ),
      'may' => 
      array (
        0 => 'мај',
        1 => 'мај',
      ),
      'june' => 
      array (
        0 => 'јуни',
        1 => 'јун.',
      ),
      'july' => 
      array (
        0 => 'јули',
        1 => 'јул.',
      ),
      'august' => 
      array (
        0 => 'август',
        1 => 'авг.',
      ),
      'september' => 
      array (
        0 => 'септември',
        1 => 'септ.',
      ),
      'october' => 
      array (
        0 => 'октомври',
        1 => 'окт.',
      ),
      'november' => 
      array (
        0 => 'ноември',
        1 => 'ноем.',
      ),
      'december' => 
      array (
        0 => 'декември',
        1 => 'дек.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'недела',
        1 => 'нед.',
      ),
      'monday' => 
      array (
        0 => 'понеделник',
        1 => 'пон.',
      ),
      'tuesday' => 
      array (
        0 => 'вторник',
        1 => 'вт.',
      ),
      'wednesday' => 
      array (
        0 => 'среда',
        1 => 'сре.',
      ),
      'friday' => 
      array (
        0 => 'петок',
        1 => 'пет.',
      ),
      'thursday' => 
      array (
        0 => 'четврток',
        1 => 'чет.',
      ),
      'saturday' => 
      array (
        0 => 'сабота',
        1 => 'саб.',
      ),
    ),
  ),
);