<?php
 $date_locale=array (
  'ja' => 
  array (
    'abstract' => 
    array (
      'today' => '今日',
      'yesterday' => '昨日',
      'two days ago' => '二日前',
      'in two days' => '二日で',
      'last week' => '先週',
      'last month' => '先月',
      'last year' => '去年',
      'last decade' => 'この10年間',
      'last century' => '前世紀',
      'last millennial' => '最後のミレニアル世代',
      'at' => 'で',
      'of' => 'の',
      'am' => '午前',
      'pm' => '午後',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => '1月',
        1 => '1月',
      ),
      'february' => 
      array (
        0 => '2月',
        1 => '2月',
      ),
      'march' => 
      array (
        0 => '3月',
        1 => '3月',
      ),
      'april' => 
      array (
        0 => '4月',
        1 => '4月',
      ),
      'may' => 
      array (
        0 => '5月',
        1 => '5月',
      ),
      'june' => 
      array (
        0 => '6月',
        1 => '6月',
      ),
      'july' => 
      array (
        0 => '7月',
        1 => '7月',
      ),
      'august' => 
      array (
        0 => '8月',
        1 => '8月',
      ),
      'september' => 
      array (
        0 => '9月',
        1 => '9月',
      ),
      'october' => 
      array (
        0 => '10月',
        1 => '10月',
      ),
      'november' => 
      array (
        0 => '11月',
        1 => '11月',
      ),
      'december' => 
      array (
        0 => '12月',
        1 => '12月',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => '日曜日',
        1 => '日',
      ),
      'monday' => 
      array (
        0 => '月曜日',
        1 => '月',
      ),
      'tuesday' => 
      array (
        0 => '火曜日',
        1 => '火',
      ),
      'wednesday' => 
      array (
        0 => '水曜日',
        1 => '水',
      ),
      'friday' => 
      array (
        0 => '金曜日',
        1 => '金',
      ),
      'thursday' => 
      array (
        0 => '木曜日',
        1 => '木',
      ),
      'saturday' => 
      array (
        0 => '土曜日',
        1 => '土',
      ),
    ),
  ),
);