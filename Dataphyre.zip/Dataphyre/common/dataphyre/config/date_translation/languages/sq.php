<?php
 $date_locale=array (
  'sq' => 
  array (
    'abstract' => 
    array (
      'today' => 'sot',
      'yesterday' => 'dje',
      'two days ago' => 'dy ditë më parë',
      'in two days' => 'në dy ditë',
      'last week' => 'javen e shkuar',
      'last month' => 'muajin e kaluar',
      'last year' => 'vitin e kaluar',
      'last decade' => 'dekadën e fundit',
      'last century' => 'shekullit të kaluar',
      'last millennial' => 'mijëvjeçarin e kaluar',
      'at' => 'në',
      'of' => 'e',
      'am' => 'e paradites',
      'pm' => 'e pasdites',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'janar',
        1 => 'jan',
      ),
      'february' => 
      array (
        0 => 'shkurt',
        1 => 'shk',
      ),
      'march' => 
      array (
        0 => 'mars',
        1 => 'mar',
      ),
      'april' => 
      array (
        0 => 'prill',
        1 => 'pri',
      ),
      'may' => 
      array (
        0 => 'maj',
        1 => 'maj',
      ),
      'june' => 
      array (
        0 => 'qershor',
        1 => 'qer',
      ),
      'july' => 
      array (
        0 => 'korrik',
        1 => 'korr',
      ),
      'august' => 
      array (
        0 => 'gusht',
        1 => 'gush',
      ),
      'september' => 
      array (
        0 => 'shtator',
        1 => 'sht',
      ),
      'october' => 
      array (
        0 => 'tetor',
        1 => 'tet',
      ),
      'november' => 
      array (
        0 => 'nëntor',
        1 => 'nën',
      ),
      'december' => 
      array (
        0 => 'dhjetor',
        1 => 'dhj',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'e diel',
        1 => 'Die',
      ),
      'monday' => 
      array (
        0 => 'e hënë',
        1 => 'Hën',
      ),
      'tuesday' => 
      array (
        0 => 'e martë',
        1 => 'Mar',
      ),
      'wednesday' => 
      array (
        0 => 'e mërkurë',
        1 => 'Mër',
      ),
      'friday' => 
      array (
        0 => 'e premte',
        1 => 'Pre',
      ),
      'thursday' => 
      array (
        0 => 'e enjte',
        1 => 'Enj',
      ),
      'saturday' => 
      array (
        0 => 'e shtunë',
        1 => 'Sht',
      ),
    ),
  ),
);