<?php
 $date_locale=array (
  'fr-CA' => 
  array (
    'abstract' => 
    array (
      'today' => 'aujourd&#39;hui',
      'yesterday' => 'hier',
      'two days ago' => 'il y a deux jours',
      'in two days' => 'dans deux jours',
      'last week' => 'la semaine dernière',
      'last month' => 'le mois dernier',
      'last year' => 'l&#39;année dernière',
      'last decade' => 'la dernière décennie',
      'last century' => 'le siècle dernier',
      'last millennial' => 'dernier millénaire',
      'at' => 'à',
      'of' => 'de',
      'am' => 'a.m.',
      'pm' => 'p.m.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'janvier',
        1 => 'janv.',
      ),
      'february' => 
      array (
        0 => 'février',
        1 => 'févr.',
      ),
      'march' => 
      array (
        0 => 'mars',
        1 => 'mars',
      ),
      'april' => 
      array (
        0 => 'avril',
        1 => 'avr.',
      ),
      'may' => 
      array (
        0 => 'mai',
        1 => 'mai',
      ),
      'june' => 
      array (
        0 => 'juin',
        1 => 'juin',
      ),
      'july' => 
      array (
        0 => 'juillet',
        1 => 'juill.',
      ),
      'august' => 
      array (
        0 => 'août',
        1 => 'août',
      ),
      'september' => 
      array (
        0 => 'septembre',
        1 => 'sept.',
      ),
      'october' => 
      array (
        0 => 'octobre',
        1 => 'oct.',
      ),
      'november' => 
      array (
        0 => 'novembre',
        1 => 'nov.',
      ),
      'december' => 
      array (
        0 => 'décembre',
        1 => 'déc.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'dimanche',
        1 => 'dim.',
      ),
      'monday' => 
      array (
        0 => 'lundi',
        1 => 'lun.',
      ),
      'tuesday' => 
      array (
        0 => 'mardi',
        1 => 'mar.',
      ),
      'wednesday' => 
      array (
        0 => 'mercredi',
        1 => 'mer.',
      ),
      'friday' => 
      array (
        0 => 'vendredi',
        1 => 'ven.',
      ),
      'thursday' => 
      array (
        0 => 'jeudi',
        1 => 'jeu.',
      ),
      'saturday' => 
      array (
        0 => 'samedi',
        1 => 'sam.',
      ),
    ),
  ),
);