<?php
 $date_locale=array (
  'de' => 
  array (
    'abstract' => 
    array (
      'today' => 'heute',
      'yesterday' => 'gestern',
      'two days ago' => 'vor zwei tagen',
      'in two days' => 'in zwei tagen',
      'last week' => 'letzte woche',
      'last month' => 'im vergangenen monat',
      'last year' => 'vergangenes jahr',
      'last decade' => 'letztes jahrzehnt',
      'last century' => 'letztes jahrhundert',
      'last millennial' => 'letzten jahrtausend',
      'at' => 'bei',
      'of' => 'von',
      'am' => 'vorm.',
      'pm' => 'nachm.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Januar',
        1 => 'Jan.',
      ),
      'february' => 
      array (
        0 => 'Februar',
        1 => 'Feb.',
      ),
      'march' => 
      array (
        0 => 'März',
        1 => 'März',
      ),
      'april' => 
      array (
        0 => 'April',
        1 => 'Apr.',
      ),
      'may' => 
      array (
        0 => 'Mai',
        1 => 'Mai',
      ),
      'june' => 
      array (
        0 => 'Juni',
        1 => 'Juni',
      ),
      'july' => 
      array (
        0 => 'Juli',
        1 => 'Juli',
      ),
      'august' => 
      array (
        0 => 'August',
        1 => 'Aug.',
      ),
      'september' => 
      array (
        0 => 'September',
        1 => 'Sep.',
      ),
      'october' => 
      array (
        0 => 'Oktober',
        1 => 'Okt.',
      ),
      'november' => 
      array (
        0 => 'November',
        1 => 'Nov.',
      ),
      'december' => 
      array (
        0 => 'Dezember',
        1 => 'Dez.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Sonntag',
        1 => 'So.',
      ),
      'monday' => 
      array (
        0 => 'Montag',
        1 => 'Mo.',
      ),
      'tuesday' => 
      array (
        0 => 'Dienstag',
        1 => 'Di.',
      ),
      'wednesday' => 
      array (
        0 => 'Mittwoch',
        1 => 'Mi.',
      ),
      'friday' => 
      array (
        0 => 'Freitag',
        1 => 'Fr.',
      ),
      'thursday' => 
      array (
        0 => 'Donnerstag',
        1 => 'Do.',
      ),
      'saturday' => 
      array (
        0 => 'Samstag',
        1 => 'Sa.',
      ),
    ),
  ),
);