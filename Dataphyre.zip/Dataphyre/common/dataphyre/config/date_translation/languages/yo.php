<?php
 $date_locale=array (
  'yo' => 
  array (
    'abstract' => 
    array (
      'today' => 'loni',
      'yesterday' => 'lana',
      'two days ago' => 'ọjọ meji seyin',
      'in two days' => 'ni ojo meji',
      'last week' => 'ose ti o koja',
      'last month' => 'osu to koja',
      'last year' => 'esi',
      'last decade' => 'ewadun to koja',
      'last century' => 'kẹhin orundun',
      'last millennial' => 'egberun odun to koja',
      'at' => 'ni',
      'of' => 'ti',
      'am' => 'Àárọ̀',
      'pm' => 'Ọ̀sán',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Oṣù Ṣẹ́rẹ́',
        1 => 'Ṣẹ́rẹ́',
      ),
      'february' => 
      array (
        0 => 'Oṣù Èrèlè',
        1 => 'Èrèlè',
      ),
      'march' => 
      array (
        0 => 'Oṣù Ẹrẹ̀nà',
        1 => 'Ẹrẹ̀nà',
      ),
      'april' => 
      array (
        0 => 'Oṣù Ìgbé',
        1 => 'Ìgbé',
      ),
      'may' => 
      array (
        0 => 'Oṣù Ẹ̀bibi',
        1 => 'Ẹ̀bibi',
      ),
      'june' => 
      array (
        0 => 'Oṣù Òkúdu',
        1 => 'Òkúdu',
      ),
      'july' => 
      array (
        0 => 'Oṣù Agẹmọ',
        1 => 'Agẹmọ',
      ),
      'august' => 
      array (
        0 => 'Oṣù Ògún',
        1 => 'Ògún',
      ),
      'september' => 
      array (
        0 => 'Oṣù Owewe',
        1 => 'Owewe',
      ),
      'october' => 
      array (
        0 => 'Oṣù Ọ̀wàrà',
        1 => 'Ọ̀wàrà',
      ),
      'november' => 
      array (
        0 => 'Oṣù Bélú',
        1 => 'Bélú',
      ),
      'december' => 
      array (
        0 => 'Oṣù Ọ̀pẹ̀',
        1 => 'Ọ̀pẹ̀',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Ọjọ́ Àìkú',
        1 => 'Àìkú',
      ),
      'monday' => 
      array (
        0 => 'Ọjọ́ Ajé',
        1 => 'Ajé',
      ),
      'tuesday' => 
      array (
        0 => 'Ọjọ́ Ìsẹ́gun',
        1 => 'Ìsẹ́gun',
      ),
      'wednesday' => 
      array (
        0 => 'Ọjọ́rú',
        1 => 'Ọjọ́rú',
      ),
      'friday' => 
      array (
        0 => 'Ọjọ́ Ẹtì',
        1 => 'Ẹtì',
      ),
      'thursday' => 
      array (
        0 => 'Ọjọ́bọ',
        1 => 'Ọjọ́bọ',
      ),
      'saturday' => 
      array (
        0 => 'Ọjọ́ Àbámẹ́ta',
        1 => 'Àbámẹ́ta',
      ),
    ),
  ),
);