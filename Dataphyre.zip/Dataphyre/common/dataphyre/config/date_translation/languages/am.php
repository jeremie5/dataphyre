<?php
 $date_locale=array (
  'am' => 
  array (
    'abstract' => 
    array (
      'today' => 'ዛሬ',
      'yesterday' => 'ትናንት',
      'two days ago' => 'ከሁለት ቀናት በፊት',
      'in two days' => 'በሁለት ቀናት ውስጥ',
      'last week' => 'ባለፈው ሳምንት',
      'last month' => 'ባለፈው ወር',
      'last year' => 'ባለፈው ዓመት',
      'last decade' => 'ባለፉት አስርት ዓመታት',
      'last century' => 'ባለፈው ክፍለ ዘመን',
      'last millennial' => 'ባለፈው ሺህ ዓመት',
      'at' => 'በ',
      'of' => 'የ',
      'am' => 'ጥዋት',
      'pm' => 'ከሰዓት',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'ጃንዩወሪ',
        1 => 'ጃንዩ',
      ),
      'february' => 
      array (
        0 => 'ፌብሩወሪ',
        1 => 'ፌብሩ',
      ),
      'march' => 
      array (
        0 => 'ማርች',
        1 => 'ማርች',
      ),
      'april' => 
      array (
        0 => 'ኤፕሪል',
        1 => 'ኤፕሪ',
      ),
      'may' => 
      array (
        0 => 'ሜይ',
        1 => 'ሜይ',
      ),
      'june' => 
      array (
        0 => 'ጁን',
        1 => 'ጁን',
      ),
      'july' => 
      array (
        0 => 'ጁላይ',
        1 => 'ጁላይ',
      ),
      'august' => 
      array (
        0 => 'ኦገስት',
        1 => 'ኦገስ',
      ),
      'september' => 
      array (
        0 => 'ሴፕቴምበር',
        1 => 'ሴፕቴ',
      ),
      'october' => 
      array (
        0 => 'ኦክቶበር',
        1 => 'ኦክቶ',
      ),
      'november' => 
      array (
        0 => 'ኖቬምበር',
        1 => 'ኖቬም',
      ),
      'december' => 
      array (
        0 => 'ዲሴምበር',
        1 => 'ዲሴም',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'እሑድ',
        1 => 'እሑድ',
      ),
      'monday' => 
      array (
        0 => 'ሰኞ',
        1 => 'ሰኞ',
      ),
      'tuesday' => 
      array (
        0 => 'ማክሰኞ',
        1 => 'ማክሰ',
      ),
      'wednesday' => 
      array (
        0 => 'ረቡዕ',
        1 => 'ረቡዕ',
      ),
      'friday' => 
      array (
        0 => 'ዓርብ',
        1 => 'ዓርብ',
      ),
      'thursday' => 
      array (
        0 => 'ሐሙስ',
        1 => 'ሐሙስ',
      ),
      'saturday' => 
      array (
        0 => 'ቅዳሜ',
        1 => 'ቅዳሜ',
      ),
    ),
  ),
);