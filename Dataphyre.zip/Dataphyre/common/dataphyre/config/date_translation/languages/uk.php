<?php
 $date_locale=array (
  'uk' => 
  array (
    'abstract' => 
    array (
      'today' => 'сьогодні',
      'yesterday' => 'вчора',
      'two days ago' => 'два дні назад',
      'in two days' => 'через два дні',
      'last week' => 'минулого тижня',
      'last month' => 'минулого місяця',
      'last year' => 'минулого року',
      'last decade' => 'останнє десятиліття',
      'last century' => 'минулого століття',
      'last millennial' => 'останнє тисячоліття',
      'at' => 'в',
      'of' => 'з',
      'am' => 'дп',
      'pm' => 'пп',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'січня',
        1 => 'січ.',
      ),
      'february' => 
      array (
        0 => 'лютого',
        1 => 'лют.',
      ),
      'march' => 
      array (
        0 => 'березня',
        1 => 'бер.',
      ),
      'april' => 
      array (
        0 => 'квітня',
        1 => 'квіт.',
      ),
      'may' => 
      array (
        0 => 'травня',
        1 => 'трав.',
      ),
      'june' => 
      array (
        0 => 'червня',
        1 => 'черв.',
      ),
      'july' => 
      array (
        0 => 'липня',
        1 => 'лип.',
      ),
      'august' => 
      array (
        0 => 'серпня',
        1 => 'серп.',
      ),
      'september' => 
      array (
        0 => 'вересня',
        1 => 'вер.',
      ),
      'october' => 
      array (
        0 => 'жовтня',
        1 => 'жовт.',
      ),
      'november' => 
      array (
        0 => 'листопада',
        1 => 'лист.',
      ),
      'december' => 
      array (
        0 => 'грудня',
        1 => 'груд.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'неділя',
        1 => 'нд',
      ),
      'monday' => 
      array (
        0 => 'понеділок',
        1 => 'пн',
      ),
      'tuesday' => 
      array (
        0 => 'вівторок',
        1 => 'вт',
      ),
      'wednesday' => 
      array (
        0 => 'середа',
        1 => 'ср',
      ),
      'friday' => 
      array (
        0 => 'пʼятниця',
        1 => 'пт',
      ),
      'thursday' => 
      array (
        0 => 'четвер',
        1 => 'чт',
      ),
      'saturday' => 
      array (
        0 => 'субота',
        1 => 'сб',
      ),
    ),
  ),
);