<?php
 $date_locale=array (
  'om' => 
  array (
    'abstract' => 
    array (
      'today' => 'har&#39;a',
      'yesterday' => 'kaleessa',
      'two days ago' => 'guyyaa lama dura',
      'in two days' => 'guyyaa lama keessatti',
      'last week' => 'torban darbe',
      'last month' => 'ji’a darbe keessa',
      'last year' => 'bara darbe',
      'last decade' => 'waggoota kurnan darban',
      'last century' => 'jaarraa darbe',
      'last millennial' => 'kan bara kumaa darbe',
      'at' => 'itti',
      'of' => 'kan',
      'am' => 'WD',
      'pm' => 'WB',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Amajjii',
        1 => 'Ama',
      ),
      'february' => 
      array (
        0 => 'Guraandhala',
        1 => 'Gur',
      ),
      'march' => 
      array (
        0 => 'Bitooteessa',
        1 => 'Bit',
      ),
      'april' => 
      array (
        0 => 'Elba',
        1 => 'Elb',
      ),
      'may' => 
      array (
        0 => 'Caamsa',
        1 => 'Cam',
      ),
      'june' => 
      array (
        0 => 'Waxabajjii',
        1 => 'Wax',
      ),
      'july' => 
      array (
        0 => 'Adooleessa',
        1 => 'Ado',
      ),
      'august' => 
      array (
        0 => 'Hagayya',
        1 => 'Hag',
      ),
      'september' => 
      array (
        0 => 'Fuulbana',
        1 => 'Ful',
      ),
      'october' => 
      array (
        0 => 'Onkololeessa',
        1 => 'Onk',
      ),
      'november' => 
      array (
        0 => 'Sadaasa',
        1 => 'Sad',
      ),
      'december' => 
      array (
        0 => 'Muddee',
        1 => 'Mud',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Dilbata',
        1 => 'Dil',
      ),
      'monday' => 
      array (
        0 => 'Wiixata',
        1 => 'Wix',
      ),
      'tuesday' => 
      array (
        0 => 'Qibxata',
        1 => 'Qib',
      ),
      'wednesday' => 
      array (
        0 => 'Roobii',
        1 => 'Rob',
      ),
      'friday' => 
      array (
        0 => 'Jimaata',
        1 => 'Jim',
      ),
      'thursday' => 
      array (
        0 => 'Kamiisa',
        1 => 'Kam',
      ),
      'saturday' => 
      array (
        0 => 'Sanbata',
        1 => 'San',
      ),
    ),
  ),
);