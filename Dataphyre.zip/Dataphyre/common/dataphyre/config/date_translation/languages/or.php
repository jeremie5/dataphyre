<?php
 $date_locale=array (
  'or' => 
  array (
    'abstract' => 
    array (
      'today' => 'ଆଜି',
      'yesterday' => 'ଗତକାଲି',
      'two days ago' => 'ଦୁଇ ଦିନ ପୂର୍ବରୁ',
      'in two days' => 'ଦୁଇ ଦିନରେ',
      'last week' => 'ଗତ ସପ୍ତାହ',
      'last month' => 'ଗତ ମାସ',
      'last year' => 'ଗତ ବର୍ଷ',
      'last decade' => 'ଗତ ଦଶନ୍ଧି',
      'last century' => 'ଗତ ଶତାବ୍ଦୀ',
      'last millennial' => 'ଗତ ସହସ୍ର ବର୍ଷ',
      'at' => 'at',
      'of' => 'ର',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'ଜାନୁଆରୀ',
        1 => 'ଜାନୁଆରୀ',
      ),
      'february' => 
      array (
        0 => 'ଫେବୃଆରୀ',
        1 => 'ଫେବୃଆରୀ',
      ),
      'march' => 
      array (
        0 => 'ମାର୍ଚ୍ଚ',
        1 => 'ମାର୍ଚ୍ଚ',
      ),
      'april' => 
      array (
        0 => 'ଅପ୍ରେଲ',
        1 => 'ଅପ୍ରେଲ',
      ),
      'may' => 
      array (
        0 => 'ମଇ',
        1 => 'ମଇ',
      ),
      'june' => 
      array (
        0 => 'ଜୁନ',
        1 => 'ଜୁନ',
      ),
      'july' => 
      array (
        0 => 'ଜୁଲାଇ',
        1 => 'ଜୁଲାଇ',
      ),
      'august' => 
      array (
        0 => 'ଅଗଷ୍ଟ',
        1 => 'ଅଗଷ୍ଟ',
      ),
      'september' => 
      array (
        0 => 'ସେପ୍ଟେମ୍ବର',
        1 => 'ସେପ୍ଟେମ୍ବର',
      ),
      'october' => 
      array (
        0 => 'ଅକ୍ଟୋବର',
        1 => 'ଅକ୍ଟୋବର',
      ),
      'november' => 
      array (
        0 => 'ନଭେମ୍ବର',
        1 => 'ନଭେମ୍ବର',
      ),
      'december' => 
      array (
        0 => 'ଡିସେମ୍ବର',
        1 => 'ଡିସେମ୍ବର',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'ରବିବାର',
        1 => 'ରବି',
      ),
      'monday' => 
      array (
        0 => 'ସୋମବାର',
        1 => 'ସୋମ',
      ),
      'tuesday' => 
      array (
        0 => 'ମଙ୍ଗଳବାର',
        1 => 'ମଙ୍ଗଳ',
      ),
      'wednesday' => 
      array (
        0 => 'ବୁଧବାର',
        1 => 'ବୁଧ',
      ),
      'friday' => 
      array (
        0 => 'ଶୁକ୍ରବାର',
        1 => 'ଶୁକ୍ର',
      ),
      'thursday' => 
      array (
        0 => 'ଗୁରୁବାର',
        1 => 'ଗୁରୁ',
      ),
      'saturday' => 
      array (
        0 => 'ଶନିବାର',
        1 => 'ଶନି',
      ),
    ),
  ),
);