<?php
 $date_locale=array (
  'lv' => 
  array (
    'abstract' => 
    array (
      'today' => 'šodien',
      'yesterday' => 'vakar',
      'two days ago' => 'pirms divām dienām',
      'in two days' => 'divās dienās',
      'last week' => 'pagājušajā nedēļā',
      'last month' => 'pagājušajā mēnesī',
      'last year' => 'pagājušais gads',
      'last decade' => 'pēdējā desmitgade',
      'last century' => 'pagājušajā gadsimtā',
      'last millennial' => 'pagājušajā tūkstošgadē',
      'at' => 'plkst',
      'of' => 'no',
      'am' => 'priekšpusdienā',
      'pm' => 'pēcpusdienā',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'janvāris',
        1 => 'janv.',
      ),
      'february' => 
      array (
        0 => 'februāris',
        1 => 'febr.',
      ),
      'march' => 
      array (
        0 => 'marts',
        1 => 'marts',
      ),
      'april' => 
      array (
        0 => 'aprīlis',
        1 => 'apr.',
      ),
      'may' => 
      array (
        0 => 'maijs',
        1 => 'maijs',
      ),
      'june' => 
      array (
        0 => 'jūnijs',
        1 => 'jūn.',
      ),
      'july' => 
      array (
        0 => 'jūlijs',
        1 => 'jūl.',
      ),
      'august' => 
      array (
        0 => 'augusts',
        1 => 'aug.',
      ),
      'september' => 
      array (
        0 => 'septembris',
        1 => 'sept.',
      ),
      'october' => 
      array (
        0 => 'oktobris',
        1 => 'okt.',
      ),
      'november' => 
      array (
        0 => 'novembris',
        1 => 'nov.',
      ),
      'december' => 
      array (
        0 => 'decembris',
        1 => 'dec.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'svētdiena',
        1 => 'svētd.',
      ),
      'monday' => 
      array (
        0 => 'pirmdiena',
        1 => 'pirmd.',
      ),
      'tuesday' => 
      array (
        0 => 'otrdiena',
        1 => 'otrd.',
      ),
      'wednesday' => 
      array (
        0 => 'trešdiena',
        1 => 'trešd.',
      ),
      'friday' => 
      array (
        0 => 'piektdiena',
        1 => 'piektd.',
      ),
      'thursday' => 
      array (
        0 => 'ceturtdiena',
        1 => 'ceturtd.',
      ),
      'saturday' => 
      array (
        0 => 'sestdiena',
        1 => 'sestd.',
      ),
    ),
  ),
);