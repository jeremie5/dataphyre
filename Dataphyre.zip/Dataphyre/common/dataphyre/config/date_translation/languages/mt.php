<?php
 $date_locale=array (
  'mt' => 
  array (
    'abstract' => 
    array (
      'today' => 'illum',
      'yesterday' => 'ilbieraħ',
      'two days ago' => 'jumejn ilu',
      'in two days' => 'f’jumejn',
      'last week' => 'il-gimgha l-ohra',
      'last month' => 'ix-xahar li għadda',
      'last year' => 'is-sena l-oħra',
      'last decade' => 'l-aħħar għaxar snin',
      'last century' => 'seklu li għadda',
      'last millennial' => 'l-aħħar millennial',
      'at' => 'fi',
      'of' => 'ta',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Jannar',
        1 => 'Jan',
      ),
      'february' => 
      array (
        0 => 'Frar',
        1 => 'Fra',
      ),
      'march' => 
      array (
        0 => 'Marzu',
        1 => 'Mar',
      ),
      'april' => 
      array (
        0 => 'April',
        1 => 'Apr',
      ),
      'may' => 
      array (
        0 => 'Mejju',
        1 => 'Mej',
      ),
      'june' => 
      array (
        0 => 'Ġunju',
        1 => 'Ġun',
      ),
      'july' => 
      array (
        0 => 'Lulju',
        1 => 'Lul',
      ),
      'august' => 
      array (
        0 => 'Awwissu',
        1 => 'Aww',
      ),
      'september' => 
      array (
        0 => 'Settembru',
        1 => 'Set',
      ),
      'october' => 
      array (
        0 => 'Ottubru',
        1 => 'Ott',
      ),
      'november' => 
      array (
        0 => 'Novembru',
        1 => 'Nov',
      ),
      'december' => 
      array (
        0 => 'Diċembru',
        1 => 'Diċ',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Il-Ħadd',
        1 => 'Ħad',
      ),
      'monday' => 
      array (
        0 => 'It-Tnejn',
        1 => 'Tne',
      ),
      'tuesday' => 
      array (
        0 => 'It-Tlieta',
        1 => 'Tli',
      ),
      'wednesday' => 
      array (
        0 => 'L-Erbgħa',
        1 => 'Erb',
      ),
      'friday' => 
      array (
        0 => 'Il-Ġimgħa',
        1 => 'Ġim',
      ),
      'thursday' => 
      array (
        0 => 'Il-Ħamis',
        1 => 'Ħam',
      ),
      'saturday' => 
      array (
        0 => 'Is-Sibt',
        1 => 'Sib',
      ),
    ),
  ),
);