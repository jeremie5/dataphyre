<?php
 $date_locale=array (
  'ha' => 
  array (
    'abstract' => 
    array (
      'today' => 'yau',
      'yesterday' => 'jiya',
      'two days ago' => 'kwana biyu da suka wuce',
      'in two days' => 'cikin kwana biyu',
      'last week' => 'makon da ya gabata',
      'last month' => 'watan da ya gabata',
      'last year' => 'shekaran da ya gabata',
      'last decade' => 'shekaru goma da suka gabata',
      'last century' => 'karni na karshe',
      'last millennial' => 'karni na karshe',
      'at' => 'a',
      'of' => 'na',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Janairu',
        1 => 'Jan',
      ),
      'february' => 
      array (
        0 => 'Faburairu',
        1 => 'Fab',
      ),
      'march' => 
      array (
        0 => 'Maris',
        1 => 'Mar',
      ),
      'april' => 
      array (
        0 => 'Afirilu',
        1 => 'Afi',
      ),
      'may' => 
      array (
        0 => 'Mayu',
        1 => 'May',
      ),
      'june' => 
      array (
        0 => 'Yuni',
        1 => 'Yun',
      ),
      'july' => 
      array (
        0 => 'Yuli',
        1 => 'Yul',
      ),
      'august' => 
      array (
        0 => 'Agusta',
        1 => 'Agu',
      ),
      'september' => 
      array (
        0 => 'Satumba',
        1 => 'Sat',
      ),
      'october' => 
      array (
        0 => 'Oktoba',
        1 => 'Okt',
      ),
      'november' => 
      array (
        0 => 'Nuwamba',
        1 => 'Nuw',
      ),
      'december' => 
      array (
        0 => 'Disamba',
        1 => 'Dis',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Lahadi',
        1 => 'Lah',
      ),
      'monday' => 
      array (
        0 => 'Litinin',
        1 => 'Lit',
      ),
      'tuesday' => 
      array (
        0 => 'Talata',
        1 => 'Tal',
      ),
      'wednesday' => 
      array (
        0 => 'Laraba',
        1 => 'Lar',
      ),
      'friday' => 
      array (
        0 => 'Jummaʼa',
        1 => 'Jum',
      ),
      'thursday' => 
      array (
        0 => 'Alhamis',
        1 => 'Alh',
      ),
      'saturday' => 
      array (
        0 => 'Asabar',
        1 => 'Asa',
      ),
    ),
  ),
);