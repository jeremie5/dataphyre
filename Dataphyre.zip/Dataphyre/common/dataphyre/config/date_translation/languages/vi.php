<?php
 $date_locale=array (
  'vi' => 
  array (
    'abstract' => 
    array (
      'today' => 'hôm nay',
      'yesterday' => 'hôm qua',
      'two days ago' => 'hai ngày trước',
      'in two days' => 'trong hai ngày',
      'last week' => 'tuần trước',
      'last month' => 'tháng trước',
      'last year' => 'năm ngoái',
      'last decade' => 'thập kỷ vừa qua',
      'last century' => 'thế kỷ trước',
      'last millennial' => 'thiên niên kỷ qua',
      'at' => 'tại',
      'of' => 'của',
      'am' => 'SA',
      'pm' => 'CH',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'tháng 1',
        1 => 'thg 1',
      ),
      'february' => 
      array (
        0 => 'tháng 2',
        1 => 'thg 2',
      ),
      'march' => 
      array (
        0 => 'tháng 3',
        1 => 'thg 3',
      ),
      'april' => 
      array (
        0 => 'tháng 4',
        1 => 'thg 4',
      ),
      'may' => 
      array (
        0 => 'tháng 5',
        1 => 'thg 5',
      ),
      'june' => 
      array (
        0 => 'tháng 6',
        1 => 'thg 6',
      ),
      'july' => 
      array (
        0 => 'tháng 7',
        1 => 'thg 7',
      ),
      'august' => 
      array (
        0 => 'tháng 8',
        1 => 'thg 8',
      ),
      'september' => 
      array (
        0 => 'tháng 9',
        1 => 'thg 9',
      ),
      'october' => 
      array (
        0 => 'tháng 10',
        1 => 'thg 10',
      ),
      'november' => 
      array (
        0 => 'tháng 11',
        1 => 'thg 11',
      ),
      'december' => 
      array (
        0 => 'tháng 12',
        1 => 'thg 12',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Chủ Nhật',
        1 => 'CN',
      ),
      'monday' => 
      array (
        0 => 'Thứ Hai',
        1 => 'Th 2',
      ),
      'tuesday' => 
      array (
        0 => 'Thứ Ba',
        1 => 'Th 3',
      ),
      'wednesday' => 
      array (
        0 => 'Thứ Tư',
        1 => 'Th 4',
      ),
      'friday' => 
      array (
        0 => 'Thứ Sáu',
        1 => 'Th 6',
      ),
      'thursday' => 
      array (
        0 => 'Thứ Năm',
        1 => 'Th 5',
      ),
      'saturday' => 
      array (
        0 => 'Thứ Bảy',
        1 => 'Th 7',
      ),
    ),
  ),
);