<?php
 $date_locale=array (
  'zu' => 
  array (
    'abstract' => 
    array (
      'today' => 'namuhla',
      'yesterday' => 'izolo',
      'two days ago' => 'ezinsukwini ezimbili ezedlule',
      'in two days' => 'ezinsukwini ezimbili',
      'last week' => 'evikini eledlule',
      'last month' => 'ngenyanga edlule',
      'last year' => 'ngonyaka odlule',
      'last decade' => 'iminyaka eyishumi edlule',
      'last century' => 'ekhulwini elidlule',
      'last millennial' => 'iminyaka eyinkulungwane yokugcina',
      'at' => 'kwe',
      'of' => 'kwe',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Januwari',
        1 => 'Jan',
      ),
      'february' => 
      array (
        0 => 'Februwari',
        1 => 'Feb',
      ),
      'march' => 
      array (
        0 => 'Mashi',
        1 => 'Mas',
      ),
      'april' => 
      array (
        0 => 'Ephreli',
        1 => 'Eph',
      ),
      'may' => 
      array (
        0 => 'Meyi',
        1 => 'Mey',
      ),
      'june' => 
      array (
        0 => 'Juni',
        1 => 'Jun',
      ),
      'july' => 
      array (
        0 => 'Julayi',
        1 => 'Jul',
      ),
      'august' => 
      array (
        0 => 'Agasti',
        1 => 'Aga',
      ),
      'september' => 
      array (
        0 => 'Septhemba',
        1 => 'Sep',
      ),
      'october' => 
      array (
        0 => 'Okthoba',
        1 => 'Okt',
      ),
      'november' => 
      array (
        0 => 'Novemba',
        1 => 'Nov',
      ),
      'december' => 
      array (
        0 => 'Disemba',
        1 => 'Dis',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'ISonto',
        1 => 'Son',
      ),
      'monday' => 
      array (
        0 => 'UMsombuluko',
        1 => 'Mso',
      ),
      'tuesday' => 
      array (
        0 => 'ULwesibili',
        1 => 'Bil',
      ),
      'wednesday' => 
      array (
        0 => 'ULwesithathu',
        1 => 'Tha',
      ),
      'friday' => 
      array (
        0 => 'ULwesihlanu',
        1 => 'Hla',
      ),
      'thursday' => 
      array (
        0 => 'ULwesine',
        1 => 'Sin',
      ),
      'saturday' => 
      array (
        0 => 'UMgqibelo',
        1 => 'Mgq',
      ),
    ),
  ),
);