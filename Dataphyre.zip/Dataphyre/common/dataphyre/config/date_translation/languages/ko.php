<?php
 $date_locale=array (
  'ko' => 
  array (
    'abstract' => 
    array (
      'today' => '오늘',
      'yesterday' => '어제',
      'two days ago' => '이틀 전',
      'in two days' => '이틀 안에',
      'last week' => '지난주',
      'last month' => '지난 달',
      'last year' => '작년',
      'last decade' => '지난 십 년',
      'last century' => '지난 세기',
      'last millennial' => '지난 천년',
      'at' => '~에',
      'of' => '의',
      'am' => '오전',
      'pm' => '오후',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => '1월',
        1 => '1월',
      ),
      'february' => 
      array (
        0 => '2월',
        1 => '2월',
      ),
      'march' => 
      array (
        0 => '3월',
        1 => '3월',
      ),
      'april' => 
      array (
        0 => '4월',
        1 => '4월',
      ),
      'may' => 
      array (
        0 => '5월',
        1 => '5월',
      ),
      'june' => 
      array (
        0 => '6월',
        1 => '6월',
      ),
      'july' => 
      array (
        0 => '7월',
        1 => '7월',
      ),
      'august' => 
      array (
        0 => '8월',
        1 => '8월',
      ),
      'september' => 
      array (
        0 => '9월',
        1 => '9월',
      ),
      'october' => 
      array (
        0 => '10월',
        1 => '10월',
      ),
      'november' => 
      array (
        0 => '11월',
        1 => '11월',
      ),
      'december' => 
      array (
        0 => '12월',
        1 => '12월',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => '일요일',
        1 => '일',
      ),
      'monday' => 
      array (
        0 => '월요일',
        1 => '월',
      ),
      'tuesday' => 
      array (
        0 => '화요일',
        1 => '화',
      ),
      'wednesday' => 
      array (
        0 => '수요일',
        1 => '수',
      ),
      'friday' => 
      array (
        0 => '금요일',
        1 => '금',
      ),
      'thursday' => 
      array (
        0 => '목요일',
        1 => '목',
      ),
      'saturday' => 
      array (
        0 => '토요일',
        1 => '토',
      ),
    ),
  ),
);