<?php
 $date_locale=array (
  'af' => 
  array (
    'abstract' => 
    array (
      'today' => 'vandag',
      'yesterday' => 'gister',
      'two days ago' => 'twee dae gelede',
      'in two days' => 'oor twee dae',
      'last week' => 'verlede week',
      'last month' => 'verlede maand',
      'last year' => 'laas jaar',
      'last decade' => 'laaste dekade',
      'last century' => 'vorige eeu',
      'last millennial' => 'laaste millennium',
      'at' => 'by',
      'of' => 'van',
      'am' => 'vm.',
      'pm' => 'nm.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Januarie',
        1 => 'Jan.',
      ),
      'february' => 
      array (
        0 => 'Februarie',
        1 => 'Feb.',
      ),
      'march' => 
      array (
        0 => 'Maart',
        1 => 'Mrt.',
      ),
      'april' => 
      array (
        0 => 'April',
        1 => 'Apr.',
      ),
      'may' => 
      array (
        0 => 'Mei',
        1 => 'Mei',
      ),
      'june' => 
      array (
        0 => 'Junie',
        1 => 'Jun.',
      ),
      'july' => 
      array (
        0 => 'Julie',
        1 => 'Jul.',
      ),
      'august' => 
      array (
        0 => 'Augustus',
        1 => 'Aug.',
      ),
      'september' => 
      array (
        0 => 'September',
        1 => 'Sep.',
      ),
      'october' => 
      array (
        0 => 'Oktober',
        1 => 'Okt.',
      ),
      'november' => 
      array (
        0 => 'November',
        1 => 'Nov.',
      ),
      'december' => 
      array (
        0 => 'Desember',
        1 => 'Des.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Sondag',
        1 => 'So.',
      ),
      'monday' => 
      array (
        0 => 'Maandag',
        1 => 'Ma.',
      ),
      'tuesday' => 
      array (
        0 => 'Dinsdag',
        1 => 'Di.',
      ),
      'wednesday' => 
      array (
        0 => 'Woensdag',
        1 => 'Wo.',
      ),
      'friday' => 
      array (
        0 => 'Vrydag',
        1 => 'Vr.',
      ),
      'thursday' => 
      array (
        0 => 'Donderdag',
        1 => 'Do.',
      ),
      'saturday' => 
      array (
        0 => 'Saterdag',
        1 => 'Sa.',
      ),
    ),
  ),
);