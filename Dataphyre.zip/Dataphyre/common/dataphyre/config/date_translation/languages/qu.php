<?php
 $date_locale=array (
  'qu' => 
  array (
    'abstract' => 
    array (
      'today' => 'kunan',
      'yesterday' => 'qayna punchaw',
      'two days ago' => 'iskay p’unchaw ñawpaqta',
      'in two days' => 'iskay punchawpi',
      'last week' => 'qayna semana',
      'last month' => 'qayna killa',
      'last year' => 'qayna wata',
      'last decade' => 'qayna chunka watakunapi',
      'last century' => 'qayna pachak watakunapi',
      'last millennial' => 'qayna waranqa wata',
      'at' => 'at',
      'of' => 'de',
      'am' => 'a.m.',
      'pm' => 'p.m.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Enero',
        1 => 'Ene',
      ),
      'february' => 
      array (
        0 => 'Febrero',
        1 => 'Feb',
      ),
      'march' => 
      array (
        0 => 'Marzo',
        1 => 'Mar',
      ),
      'april' => 
      array (
        0 => 'Abril',
        1 => 'Abr',
      ),
      'may' => 
      array (
        0 => 'Mayo',
        1 => 'May',
      ),
      'june' => 
      array (
        0 => 'Junio',
        1 => 'Jun',
      ),
      'july' => 
      array (
        0 => 'Julio',
        1 => 'Jul',
      ),
      'august' => 
      array (
        0 => 'Agosto',
        1 => 'Ago',
      ),
      'september' => 
      array (
        0 => 'Setiembre',
        1 => 'Set',
      ),
      'october' => 
      array (
        0 => 'Octubre',
        1 => 'Oct',
      ),
      'november' => 
      array (
        0 => 'Noviembre',
        1 => 'Nov',
      ),
      'december' => 
      array (
        0 => 'Diciembre',
        1 => 'Dic',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Domingo',
        1 => 'Dom',
      ),
      'monday' => 
      array (
        0 => 'Lunes',
        1 => 'Lun',
      ),
      'tuesday' => 
      array (
        0 => 'Martes',
        1 => 'Mar',
      ),
      'wednesday' => 
      array (
        0 => 'Miércoles',
        1 => 'Mié',
      ),
      'friday' => 
      array (
        0 => 'Viernes',
        1 => 'Vie',
      ),
      'thursday' => 
      array (
        0 => 'Jueves',
        1 => 'Jue',
      ),
      'saturday' => 
      array (
        0 => 'Sábado',
        1 => 'Sab',
      ),
    ),
  ),
);