<?php
 $date_locale=array (
  'ti' => 
  array (
    'abstract' => 
    array (
      'today' => 'ሎምዓንቲ',
      'yesterday' => 'ትማሊ',
      'two days ago' => 'ቅድሚ ክልተ መዓልቲ',
      'in two days' => 'ኣብ ክልተ መዓልቲ',
      'last week' => 'ዝሓለፈ ሰሙን',
      'last month' => 'ዝሓለፈ ወርሒ',
      'last year' => 'ዝሓለፈ ዓመት',
      'last decade' => 'ዝሓለፈ ዓሰርተ ዓመት',
      'last century' => 'ዝሓለፈ ክፍለ ዘመን',
      'last millennial' => 'ዝሓለፈ ሽሕ ዓመት',
      'at' => 'ኣብ',
      'of' => 'ካብ',
      'am' => 'ንጉሆ ሰዓተ',
      'pm' => 'ድሕር ሰዓት',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'ጥሪ',
        1 => 'ጥሪ',
      ),
      'february' => 
      array (
        0 => 'ለካቲት',
        1 => 'ለካ',
      ),
      'march' => 
      array (
        0 => 'መጋቢት',
        1 => 'መጋ',
      ),
      'april' => 
      array (
        0 => 'ሚያዝያ',
        1 => 'ሚያ',
      ),
      'may' => 
      array (
        0 => 'ግንቦት',
        1 => 'ግን',
      ),
      'june' => 
      array (
        0 => 'ሰነ',
        1 => 'ሰነ',
      ),
      'july' => 
      array (
        0 => 'ሓምለ',
        1 => 'ሓም',
      ),
      'august' => 
      array (
        0 => 'ነሓሰ',
        1 => 'ነሓ',
      ),
      'september' => 
      array (
        0 => 'መስከረም',
        1 => 'መስ',
      ),
      'october' => 
      array (
        0 => 'ጥቅምቲ',
        1 => 'ጥቅ',
      ),
      'november' => 
      array (
        0 => 'ሕዳር',
        1 => 'ሕዳ',
      ),
      'december' => 
      array (
        0 => 'ታሕሳስ',
        1 => 'ታሕ',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'ሰንበት',
        1 => 'ሰን',
      ),
      'monday' => 
      array (
        0 => 'ሰኑይ',
        1 => 'ሰኑ',
      ),
      'tuesday' => 
      array (
        0 => 'ሠሉስ',
        1 => 'ሰሉ',
      ),
      'wednesday' => 
      array (
        0 => 'ረቡዕ',
        1 => 'ረቡ',
      ),
      'friday' => 
      array (
        0 => 'ዓርቢ',
        1 => 'ዓር',
      ),
      'thursday' => 
      array (
        0 => 'ኃሙስ',
        1 => 'ሓሙ',
      ),
      'saturday' => 
      array (
        0 => 'ቀዳም',
        1 => 'ቀዳ',
      ),
    ),
  ),
);