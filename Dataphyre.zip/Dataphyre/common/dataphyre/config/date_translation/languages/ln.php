<?php
 $date_locale=array (
  'ln' => 
  array (
    'abstract' => 
    array (
      'today' => 'lelo',
      'yesterday' => 'lobi eleki',
      'two days ago' => 'mikolo mibale eleki',
      'in two days' => 'na mikolo mibale',
      'last week' => 'pɔsɔ eleki',
      'last month' => 'sanza eleki',
      'last year' => 'na mbula eleki',
      'last decade' => 'mbula zomi oyo euti koleka',
      'last century' => 'ekeke eleki',
      'last millennial' => 'mbula nkóto oyo eleki',
      'at' => 'na',
      'of' => 'ya',
      'am' => 'ntɔ́ngɔ́',
      'pm' => 'mpókwa',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'sánzá ya yambo',
        1 => 'yan',
      ),
      'february' => 
      array (
        0 => 'sánzá ya míbalé',
        1 => 'fbl',
      ),
      'march' => 
      array (
        0 => 'sánzá ya mísáto',
        1 => 'msi',
      ),
      'april' => 
      array (
        0 => 'sánzá ya mínei',
        1 => 'apl',
      ),
      'may' => 
      array (
        0 => 'sánzá ya mítáno',
        1 => 'mai',
      ),
      'june' => 
      array (
        0 => 'sánzá ya motóbá',
        1 => 'yun',
      ),
      'july' => 
      array (
        0 => 'sánzá ya nsambo',
        1 => 'yul',
      ),
      'august' => 
      array (
        0 => 'sánzá ya mwambe',
        1 => 'agt',
      ),
      'september' => 
      array (
        0 => 'sánzá ya libwa',
        1 => 'stb',
      ),
      'october' => 
      array (
        0 => 'sánzá ya zómi',
        1 => 'ɔtb',
      ),
      'november' => 
      array (
        0 => 'sánzá ya zómi na mɔ̌kɔ́',
        1 => 'nvb',
      ),
      'december' => 
      array (
        0 => 'sánzá ya zómi na míbalé',
        1 => 'dsb',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'eyenga',
        1 => 'eye',
      ),
      'monday' => 
      array (
        0 => 'mokɔlɔ mwa yambo',
        1 => 'ybo',
      ),
      'tuesday' => 
      array (
        0 => 'mokɔlɔ mwa míbalé',
        1 => 'mbl',
      ),
      'wednesday' => 
      array (
        0 => 'mokɔlɔ mwa mísáto',
        1 => 'mst',
      ),
      'friday' => 
      array (
        0 => 'mokɔlɔ ya mítáno',
        1 => 'mtn',
      ),
      'thursday' => 
      array (
        0 => 'mokɔlɔ ya mínéi',
        1 => 'min',
      ),
      'saturday' => 
      array (
        0 => 'mpɔ́sɔ',
        1 => 'mps',
      ),
    ),
  ),
);