<?php
 $date_locale=array (
  'ps' => 
  array (
    'abstract' => 
    array (
      'today' => 'نن',
      'yesterday' => 'پرون',
      'two days ago' => 'دوه ورځې وړاندې',
      'in two days' => 'په دوو ورځو کې',
      'last week' => 'تېره اونۍ',
      'last month' => 'تیره میاشت',
      'last year' => 'تېر کال',
      'last decade' => 'تیره لسیزه',
      'last century' => 'تیره پیړۍ',
      'last millennial' => 'تېر زر کلن',
      'at' => 'په',
      'of' => 'د',
      'am' => 'غ.م.',
      'pm' => 'غ.و.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'وری',
        1 => 'وری',
      ),
      'february' => 
      array (
        0 => 'غویی',
        1 => 'غویی',
      ),
      'march' => 
      array (
        0 => 'غبرگولی',
        1 => 'غبرگولی',
      ),
      'april' => 
      array (
        0 => 'چنگاښ',
        1 => 'چنگاښ',
      ),
      'may' => 
      array (
        0 => 'زمری',
        1 => 'زمری',
      ),
      'june' => 
      array (
        0 => 'وږی',
        1 => 'وږی',
      ),
      'july' => 
      array (
        0 => 'تله',
        1 => 'تله',
      ),
      'august' => 
      array (
        0 => 'لړم',
        1 => 'لړم',
      ),
      'september' => 
      array (
        0 => 'لیندۍ',
        1 => 'لیندۍ',
      ),
      'october' => 
      array (
        0 => 'مرغومی',
        1 => 'مرغومی',
      ),
      'november' => 
      array (
        0 => 'سلواغه',
        1 => 'سلواغه',
      ),
      'december' => 
      array (
        0 => 'کب',
        1 => 'کب',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'يونۍ',
        1 => 'يونۍ',
      ),
      'monday' => 
      array (
        0 => 'دونۍ',
        1 => 'دونۍ',
      ),
      'tuesday' => 
      array (
        0 => 'درېنۍ',
        1 => 'درېنۍ',
      ),
      'wednesday' => 
      array (
        0 => 'څلرنۍ',
        1 => 'څلرنۍ',
      ),
      'friday' => 
      array (
        0 => 'جمعه',
        1 => 'جمعه',
      ),
      'thursday' => 
      array (
        0 => 'پينځنۍ',
        1 => 'پينځنۍ',
      ),
      'saturday' => 
      array (
        0 => 'اونۍ',
        1 => 'اونۍ',
      ),
    ),
  ),
);