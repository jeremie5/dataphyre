<?php
 $date_locale=array (
  'sk' => 
  array (
    'abstract' => 
    array (
      'today' => 'dnes',
      'yesterday' => 'včera',
      'two days ago' => 'pred dvoma dňami',
      'in two days' => 'v dvoch dňoch',
      'last week' => 'minulý týždeň',
      'last month' => 'minulý mesiac',
      'last year' => 'minulý rok',
      'last decade' => 'posledné desaťročie',
      'last century' => 'posledné storočie',
      'last millennial' => 'minulého tisícročia',
      'at' => 'pri',
      'of' => 'z',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'januára',
        1 => 'jan',
      ),
      'february' => 
      array (
        0 => 'februára',
        1 => 'feb',
      ),
      'march' => 
      array (
        0 => 'marca',
        1 => 'mar',
      ),
      'april' => 
      array (
        0 => 'apríla',
        1 => 'apr',
      ),
      'may' => 
      array (
        0 => 'mája',
        1 => 'máj',
      ),
      'june' => 
      array (
        0 => 'júna',
        1 => 'jún',
      ),
      'july' => 
      array (
        0 => 'júla',
        1 => 'júl',
      ),
      'august' => 
      array (
        0 => 'augusta',
        1 => 'aug',
      ),
      'september' => 
      array (
        0 => 'septembra',
        1 => 'sep',
      ),
      'october' => 
      array (
        0 => 'októbra',
        1 => 'okt',
      ),
      'november' => 
      array (
        0 => 'novembra',
        1 => 'nov',
      ),
      'december' => 
      array (
        0 => 'decembra',
        1 => 'dec',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'nedeľa',
        1 => 'ne',
      ),
      'monday' => 
      array (
        0 => 'pondelok',
        1 => 'po',
      ),
      'tuesday' => 
      array (
        0 => 'utorok',
        1 => 'ut',
      ),
      'wednesday' => 
      array (
        0 => 'streda',
        1 => 'st',
      ),
      'friday' => 
      array (
        0 => 'piatok',
        1 => 'pi',
      ),
      'thursday' => 
      array (
        0 => 'štvrtok',
        1 => 'št',
      ),
      'saturday' => 
      array (
        0 => 'sobota',
        1 => 'so',
      ),
    ),
  ),
);