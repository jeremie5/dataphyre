<?php
 $date_locale=array (
  'uz' => 
  array (
    'abstract' => 
    array (
      'today' => 'bugun',
      'yesterday' => 'kecha',
      'two days ago' => 'ikki kun oldin',
      'in two days' => 'ikki kun ichida',
      'last week' => 'o&#39;tgan hafta',
      'last month' => 'o `tgan oy',
      'last year' => 'o&#39;tgan yili',
      'last decade' => 'so&#39;nggi o&#39;n yil',
      'last century' => 'o&#39;tgan asr',
      'last millennial' => 'oxirgi ming yillik',
      'at' => 'da',
      'of' => 'ning',
      'am' => 'TO',
      'pm' => 'TK',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'yanvar',
        1 => 'yan',
      ),
      'february' => 
      array (
        0 => 'fevral',
        1 => 'fev',
      ),
      'march' => 
      array (
        0 => 'mart',
        1 => 'mar',
      ),
      'april' => 
      array (
        0 => 'aprel',
        1 => 'apr',
      ),
      'may' => 
      array (
        0 => 'may',
        1 => 'may',
      ),
      'june' => 
      array (
        0 => 'iyun',
        1 => 'iyn',
      ),
      'july' => 
      array (
        0 => 'iyul',
        1 => 'iyl',
      ),
      'august' => 
      array (
        0 => 'avgust',
        1 => 'avg',
      ),
      'september' => 
      array (
        0 => 'sentabr',
        1 => 'sen',
      ),
      'october' => 
      array (
        0 => 'oktabr',
        1 => 'okt',
      ),
      'november' => 
      array (
        0 => 'noyabr',
        1 => 'noy',
      ),
      'december' => 
      array (
        0 => 'dekabr',
        1 => 'dek',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'yakshanba',
        1 => 'Yak',
      ),
      'monday' => 
      array (
        0 => 'dushanba',
        1 => 'Dush',
      ),
      'tuesday' => 
      array (
        0 => 'seshanba',
        1 => 'Sesh',
      ),
      'wednesday' => 
      array (
        0 => 'chorshanba',
        1 => 'Chor',
      ),
      'friday' => 
      array (
        0 => 'juma',
        1 => 'Jum',
      ),
      'thursday' => 
      array (
        0 => 'payshanba',
        1 => 'Pay',
      ),
      'saturday' => 
      array (
        0 => 'shanba',
        1 => 'Shan',
      ),
    ),
  ),
);