<?php
 $date_locale=array (
  'ta' => 
  array (
    'abstract' => 
    array (
      'today' => 'இன்று',
      'yesterday' => 'நேற்று',
      'two days ago' => 'இரண்டு நாட்களுக்கு முன்பு',
      'in two days' => 'இரண்டு நாட்களுக்குள்',
      'last week' => 'கடந்த வாரம்',
      'last month' => 'கடந்த மாதம்',
      'last year' => 'கடந்த ஆண்டு',
      'last decade' => 'கடந்த தசாப்தம்',
      'last century' => 'கடந்த நூற்றாண்டு',
      'last millennial' => 'கடந்த ஆயிரமாண்டு',
      'at' => 'மணிக்கு',
      'of' => 'இன்',
      'am' => 'முற்பகல்',
      'pm' => 'பிற்பகல்',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'ஜனவரி',
        1 => 'ஜன.',
      ),
      'february' => 
      array (
        0 => 'பிப்ரவரி',
        1 => 'பிப்.',
      ),
      'march' => 
      array (
        0 => 'மார்ச்',
        1 => 'மார்.',
      ),
      'april' => 
      array (
        0 => 'ஏப்ரல்',
        1 => 'ஏப்.',
      ),
      'may' => 
      array (
        0 => 'மே',
        1 => 'மே',
      ),
      'june' => 
      array (
        0 => 'ஜூன்',
        1 => 'ஜூன்',
      ),
      'july' => 
      array (
        0 => 'ஜூலை',
        1 => 'ஜூலை',
      ),
      'august' => 
      array (
        0 => 'ஆகஸ்ட்',
        1 => 'ஆக.',
      ),
      'september' => 
      array (
        0 => 'செப்டம்பர்',
        1 => 'செப்.',
      ),
      'october' => 
      array (
        0 => 'அக்டோபர்',
        1 => 'அக்.',
      ),
      'november' => 
      array (
        0 => 'நவம்பர்',
        1 => 'நவ.',
      ),
      'december' => 
      array (
        0 => 'டிசம்பர்',
        1 => 'டிச.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'ஞாயிறு',
        1 => 'ஞாயி.',
      ),
      'monday' => 
      array (
        0 => 'திங்கள்',
        1 => 'திங்.',
      ),
      'tuesday' => 
      array (
        0 => 'செவ்வாய்',
        1 => 'செவ்.',
      ),
      'wednesday' => 
      array (
        0 => 'புதன்',
        1 => 'புத.',
      ),
      'friday' => 
      array (
        0 => 'வெள்ளி',
        1 => 'வெள்.',
      ),
      'thursday' => 
      array (
        0 => 'வியாழன்',
        1 => 'வியா.',
      ),
      'saturday' => 
      array (
        0 => 'சனி',
        1 => 'சனி',
      ),
    ),
  ),
);