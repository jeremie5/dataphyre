<?php
 $date_locale=array (
  'bg' => 
  array (
    'abstract' => 
    array (
      'today' => 'днес',
      'yesterday' => 'вчера',
      'two days ago' => 'преди два дни',
      'in two days' => 'след два дни',
      'last week' => 'миналата седмица',
      'last month' => 'миналия месец',
      'last year' => 'миналата година',
      'last decade' => 'последното десетилетие',
      'last century' => 'последния век',
      'last millennial' => 'последното хилядолетие',
      'at' => 'при',
      'of' => 'на',
      'am' => 'пр.об.',
      'pm' => 'сл.об.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'януари',
        1 => 'яну',
      ),
      'february' => 
      array (
        0 => 'февруари',
        1 => 'фев',
      ),
      'march' => 
      array (
        0 => 'март',
        1 => 'март',
      ),
      'april' => 
      array (
        0 => 'април',
        1 => 'апр',
      ),
      'may' => 
      array (
        0 => 'май',
        1 => 'май',
      ),
      'june' => 
      array (
        0 => 'юни',
        1 => 'юни',
      ),
      'july' => 
      array (
        0 => 'юли',
        1 => 'юли',
      ),
      'august' => 
      array (
        0 => 'август',
        1 => 'авг',
      ),
      'september' => 
      array (
        0 => 'септември',
        1 => 'сеп',
      ),
      'october' => 
      array (
        0 => 'октомври',
        1 => 'окт',
      ),
      'november' => 
      array (
        0 => 'ноември',
        1 => 'ное',
      ),
      'december' => 
      array (
        0 => 'декември',
        1 => 'дек',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'неделя',
        1 => 'нд',
      ),
      'monday' => 
      array (
        0 => 'понеделник',
        1 => 'пн',
      ),
      'tuesday' => 
      array (
        0 => 'вторник',
        1 => 'вт',
      ),
      'wednesday' => 
      array (
        0 => 'сряда',
        1 => 'ср',
      ),
      'friday' => 
      array (
        0 => 'петък',
        1 => 'пт',
      ),
      'thursday' => 
      array (
        0 => 'четвъртък',
        1 => 'чт',
      ),
      'saturday' => 
      array (
        0 => 'събота',
        1 => 'сб',
      ),
    ),
  ),
);