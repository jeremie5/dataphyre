<?php
 $date_locale=array (
  'zh-TW' => 
  array (
    'abstract' => 
    array (
      'today' => '今天',
      'yesterday' => '昨天',
      'two days ago' => '兩天前',
      'in two days' => '在兩天',
      'last week' => '上個星期',
      'last month' => '上個月',
      'last year' => '去年',
      'last decade' => '過去十年',
      'last century' => '上世紀',
      'last millennial' => '上個千禧一代',
      'at' => '在',
      'of' => '的',
      'am' => '上午',
      'pm' => '下午',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => '1月',
        1 => '1月',
      ),
      'february' => 
      array (
        0 => '2月',
        1 => '2月',
      ),
      'march' => 
      array (
        0 => '3月',
        1 => '3月',
      ),
      'april' => 
      array (
        0 => '4月',
        1 => '4月',
      ),
      'may' => 
      array (
        0 => '5月',
        1 => '5月',
      ),
      'june' => 
      array (
        0 => '6月',
        1 => '6月',
      ),
      'july' => 
      array (
        0 => '7月',
        1 => '7月',
      ),
      'august' => 
      array (
        0 => '8月',
        1 => '8月',
      ),
      'september' => 
      array (
        0 => '9月',
        1 => '9月',
      ),
      'october' => 
      array (
        0 => '10月',
        1 => '10月',
      ),
      'november' => 
      array (
        0 => '11月',
        1 => '11月',
      ),
      'december' => 
      array (
        0 => '12月',
        1 => '12月',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => '星期日',
        1 => '週日',
      ),
      'monday' => 
      array (
        0 => '星期一',
        1 => '週一',
      ),
      'tuesday' => 
      array (
        0 => '星期二',
        1 => '週二',
      ),
      'wednesday' => 
      array (
        0 => '星期三',
        1 => '週三',
      ),
      'friday' => 
      array (
        0 => '星期五',
        1 => '週五',
      ),
      'thursday' => 
      array (
        0 => '星期四',
        1 => '週四',
      ),
      'saturday' => 
      array (
        0 => '星期六',
        1 => '週六',
      ),
    ),
  ),
);