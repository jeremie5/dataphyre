<?php
 $date_locale=array (
  'sn' => 
  array (
    'abstract' => 
    array (
      'today' => 'nhasi',
      'yesterday' => 'nezuro',
      'two days ago' => 'mazuva maviri apfuura',
      'in two days' => 'mumazuva maviri',
      'last week' => 'vhiki rapera',
      'last month' => 'mwedzi wapfuura',
      'last year' => 'gore rapera',
      'last decade' => 'makore gumi apfuura',
      'last century' => 'zana remakore rapfuura',
      'last millennial' => 'mireniyumu yekupedzisira',
      'at' => 'pa',
      'of' => 'ye',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Ndira',
        1 => 'Ndi',
      ),
      'february' => 
      array (
        0 => 'Kukadzi',
        1 => 'Kuk',
      ),
      'march' => 
      array (
        0 => 'Kurume',
        1 => 'Kur',
      ),
      'april' => 
      array (
        0 => 'Kubvumbi',
        1 => 'Kub',
      ),
      'may' => 
      array (
        0 => 'Chivabvu',
        1 => 'Chv',
      ),
      'june' => 
      array (
        0 => 'Chikumi',
        1 => 'Chk',
      ),
      'july' => 
      array (
        0 => 'Chikunguru',
        1 => 'Chg',
      ),
      'august' => 
      array (
        0 => 'Nyamavhuvhu',
        1 => 'Nya',
      ),
      'september' => 
      array (
        0 => 'Gunyana',
        1 => 'Gun',
      ),
      'october' => 
      array (
        0 => 'Gumiguru',
        1 => 'Gum',
      ),
      'november' => 
      array (
        0 => 'Mbudzi',
        1 => 'Mbu',
      ),
      'december' => 
      array (
        0 => 'Zvita',
        1 => 'Zvi',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Svondo',
        1 => 'Svo',
      ),
      'monday' => 
      array (
        0 => 'Muvhuro',
        1 => 'Muv',
      ),
      'tuesday' => 
      array (
        0 => 'Chipiri',
        1 => 'Chp',
      ),
      'wednesday' => 
      array (
        0 => 'Chitatu',
        1 => 'Cht',
      ),
      'friday' => 
      array (
        0 => 'Chishanu',
        1 => 'Chs',
      ),
      'thursday' => 
      array (
        0 => 'China',
        1 => 'Chn',
      ),
      'saturday' => 
      array (
        0 => 'Mugovera',
        1 => 'Mug',
      ),
    ),
  ),
);