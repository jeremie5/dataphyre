<?php
 $date_locale=array (
  'bs' => 
  array (
    'abstract' => 
    array (
      'today' => 'danas',
      'yesterday' => 'juče',
      'two days ago' => 'prije dva dana',
      'in two days' => 'za dva dana',
      'last week' => 'prošle sedmice',
      'last month' => 'prošli mjesec',
      'last year' => 'prošle godine',
      'last decade' => 'prošle decenije',
      'last century' => 'prošlog veka',
      'last millennial' => 'prošlog milenijuma',
      'at' => 'at',
      'of' => 'of',
      'am' => 'prijepodne',
      'pm' => 'popodne',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'januar',
        1 => 'jan',
      ),
      'february' => 
      array (
        0 => 'februar',
        1 => 'feb',
      ),
      'march' => 
      array (
        0 => 'mart',
        1 => 'mar',
      ),
      'april' => 
      array (
        0 => 'april',
        1 => 'apr',
      ),
      'may' => 
      array (
        0 => 'maj',
        1 => 'maj',
      ),
      'june' => 
      array (
        0 => 'juni',
        1 => 'jun',
      ),
      'july' => 
      array (
        0 => 'juli',
        1 => 'jul',
      ),
      'august' => 
      array (
        0 => 'avgust',
        1 => 'avg',
      ),
      'september' => 
      array (
        0 => 'septembar',
        1 => 'sep',
      ),
      'october' => 
      array (
        0 => 'oktobar',
        1 => 'okt',
      ),
      'november' => 
      array (
        0 => 'novembar',
        1 => 'nov',
      ),
      'december' => 
      array (
        0 => 'decembar',
        1 => 'dec',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'nedjelja',
        1 => 'ned',
      ),
      'monday' => 
      array (
        0 => 'ponedjeljak',
        1 => 'pon',
      ),
      'tuesday' => 
      array (
        0 => 'utorak',
        1 => 'uto',
      ),
      'wednesday' => 
      array (
        0 => 'srijeda',
        1 => 'sri',
      ),
      'friday' => 
      array (
        0 => 'petak',
        1 => 'pet',
      ),
      'thursday' => 
      array (
        0 => 'četvrtak',
        1 => 'čet',
      ),
      'saturday' => 
      array (
        0 => 'subota',
        1 => 'sub',
      ),
    ),
  ),
);