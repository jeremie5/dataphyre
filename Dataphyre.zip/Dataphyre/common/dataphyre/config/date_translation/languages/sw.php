<?php
 $date_locale=array (
  'sw' => 
  array (
    'abstract' => 
    array (
      'today' => 'leo',
      'yesterday' => 'jana',
      'two days ago' => 'siku mbili zilizopita',
      'in two days' => 'katika siku mbili',
      'last week' => 'wiki iliyopita',
      'last month' => 'mwezi uliopita',
      'last year' => 'mwaka jana',
      'last decade' => 'muongo uliopita',
      'last century' => 'karne iliyopita',
      'last millennial' => 'milenia ya mwisho',
      'at' => 'katika',
      'of' => 'ya',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Januari',
        1 => 'Jan',
      ),
      'february' => 
      array (
        0 => 'Februari',
        1 => 'Feb',
      ),
      'march' => 
      array (
        0 => 'Machi',
        1 => 'Mac',
      ),
      'april' => 
      array (
        0 => 'Aprili',
        1 => 'Apr',
      ),
      'may' => 
      array (
        0 => 'Mei',
        1 => 'Mei',
      ),
      'june' => 
      array (
        0 => 'Juni',
        1 => 'Jun',
      ),
      'july' => 
      array (
        0 => 'Julai',
        1 => 'Jul',
      ),
      'august' => 
      array (
        0 => 'Agosti',
        1 => 'Ago',
      ),
      'september' => 
      array (
        0 => 'Septemba',
        1 => 'Sep',
      ),
      'october' => 
      array (
        0 => 'Oktoba',
        1 => 'Okt',
      ),
      'november' => 
      array (
        0 => 'Novemba',
        1 => 'Nov',
      ),
      'december' => 
      array (
        0 => 'Desemba',
        1 => 'Des',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Jumapili',
        1 => 'Jumapili',
      ),
      'monday' => 
      array (
        0 => 'Jumatatu',
        1 => 'Jumatatu',
      ),
      'tuesday' => 
      array (
        0 => 'Jumanne',
        1 => 'Jumanne',
      ),
      'wednesday' => 
      array (
        0 => 'Jumatano',
        1 => 'Jumatano',
      ),
      'friday' => 
      array (
        0 => 'Ijumaa',
        1 => 'Ijumaa',
      ),
      'thursday' => 
      array (
        0 => 'Alhamisi',
        1 => 'Alhamisi',
      ),
      'saturday' => 
      array (
        0 => 'Jumamosi',
        1 => 'Jumamosi',
      ),
    ),
  ),
);