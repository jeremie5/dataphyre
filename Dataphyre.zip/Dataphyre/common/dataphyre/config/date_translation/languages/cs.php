<?php
 $date_locale=array (
  'cs' => 
  array (
    'abstract' => 
    array (
      'today' => 'dnes',
      'yesterday' => 'včera',
      'two days ago' => 'před dvěma dny',
      'in two days' => 'za dva dny',
      'last week' => 'minulý týden',
      'last month' => 'minulý měsíc',
      'last year' => 'minulý rok',
      'last decade' => 'poslední dekáda',
      'last century' => 'minulé století',
      'last millennial' => 'minulého tisíciletí',
      'at' => 'na',
      'of' => 'z',
      'am' => 'dop.',
      'pm' => 'odp.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'ledna',
        1 => 'led',
      ),
      'february' => 
      array (
        0 => 'února',
        1 => 'úno',
      ),
      'march' => 
      array (
        0 => 'března',
        1 => 'bře',
      ),
      'april' => 
      array (
        0 => 'dubna',
        1 => 'dub',
      ),
      'may' => 
      array (
        0 => 'května',
        1 => 'kvě',
      ),
      'june' => 
      array (
        0 => 'června',
        1 => 'čvn',
      ),
      'july' => 
      array (
        0 => 'července',
        1 => 'čvc',
      ),
      'august' => 
      array (
        0 => 'srpna',
        1 => 'srp',
      ),
      'september' => 
      array (
        0 => 'září',
        1 => 'zář',
      ),
      'october' => 
      array (
        0 => 'října',
        1 => 'říj',
      ),
      'november' => 
      array (
        0 => 'listopadu',
        1 => 'lis',
      ),
      'december' => 
      array (
        0 => 'prosince',
        1 => 'pro',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'neděle',
        1 => 'ne',
      ),
      'monday' => 
      array (
        0 => 'pondělí',
        1 => 'po',
      ),
      'tuesday' => 
      array (
        0 => 'úterý',
        1 => 'út',
      ),
      'wednesday' => 
      array (
        0 => 'středa',
        1 => 'st',
      ),
      'friday' => 
      array (
        0 => 'pátek',
        1 => 'pá',
      ),
      'thursday' => 
      array (
        0 => 'čtvrtek',
        1 => 'čt',
      ),
      'saturday' => 
      array (
        0 => 'sobota',
        1 => 'so',
      ),
    ),
  ),
);