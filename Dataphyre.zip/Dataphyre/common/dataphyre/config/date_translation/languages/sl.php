<?php
 $date_locale=array (
  'sl' => 
  array (
    'abstract' => 
    array (
      'today' => 'danes',
      'yesterday' => 'včeraj',
      'two days ago' => 'dva dni nazaj',
      'in two days' => 'v dveh dneh',
      'last week' => 'prejšnji teden',
      'last month' => 'prejšnji mesec',
      'last year' => 'lansko leto',
      'last decade' => 'zadnje desetletje',
      'last century' => 'prejšnje stoletje',
      'last millennial' => 'zadnje tisočletje',
      'at' => 'pri',
      'of' => 'od',
      'am' => 'dop.',
      'pm' => 'pop.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'januar',
        1 => 'jan.',
      ),
      'february' => 
      array (
        0 => 'februar',
        1 => 'feb.',
      ),
      'march' => 
      array (
        0 => 'marec',
        1 => 'mar.',
      ),
      'april' => 
      array (
        0 => 'april',
        1 => 'apr.',
      ),
      'may' => 
      array (
        0 => 'maj',
        1 => 'maj',
      ),
      'june' => 
      array (
        0 => 'junij',
        1 => 'jun.',
      ),
      'july' => 
      array (
        0 => 'julij',
        1 => 'jul.',
      ),
      'august' => 
      array (
        0 => 'avgust',
        1 => 'avg.',
      ),
      'september' => 
      array (
        0 => 'september',
        1 => 'sep.',
      ),
      'october' => 
      array (
        0 => 'oktober',
        1 => 'okt.',
      ),
      'november' => 
      array (
        0 => 'november',
        1 => 'nov.',
      ),
      'december' => 
      array (
        0 => 'december',
        1 => 'dec.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'nedelja',
        1 => 'ned.',
      ),
      'monday' => 
      array (
        0 => 'ponedeljek',
        1 => 'pon.',
      ),
      'tuesday' => 
      array (
        0 => 'torek',
        1 => 'tor.',
      ),
      'wednesday' => 
      array (
        0 => 'sreda',
        1 => 'sre.',
      ),
      'friday' => 
      array (
        0 => 'petek',
        1 => 'pet.',
      ),
      'thursday' => 
      array (
        0 => 'četrtek',
        1 => 'čet.',
      ),
      'saturday' => 
      array (
        0 => 'sobota',
        1 => 'sob.',
      ),
    ),
  ),
);