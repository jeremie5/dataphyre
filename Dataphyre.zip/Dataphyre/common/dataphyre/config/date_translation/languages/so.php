<?php
 $date_locale=array (
  'so' => 
  array (
    'abstract' => 
    array (
      'today' => 'maanta',
      'yesterday' => 'shalay',
      'two days ago' => 'laba maalmood ka hor',
      'in two days' => 'laba maalmood gudahood',
      'last week' => 'usbuucii hore',
      'last month' => 'bishii hore',
      'last year' => 'sanadkii la soo dhaafay',
      'last decade' => 'tobankii sano ee la soo dhaafay',
      'last century' => 'qarnigii hore',
      'last millennial' => 'kun-sano ee ugu dambeeyay',
      'at' => 'at',
      'of' => 'ee',
      'am' => 'sn.',
      'pm' => 'gn.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Bisha Koobaad',
        1 => 'Kob',
      ),
      'february' => 
      array (
        0 => 'Bisha Labaad',
        1 => 'Lab',
      ),
      'march' => 
      array (
        0 => 'Bisha Saddexaad',
        1 => 'Sad',
      ),
      'april' => 
      array (
        0 => 'Bisha Afraad',
        1 => 'Afr',
      ),
      'may' => 
      array (
        0 => 'Bisha Shanaad',
        1 => 'Sha',
      ),
      'june' => 
      array (
        0 => 'Bisha Lixaad',
        1 => 'Lix',
      ),
      'july' => 
      array (
        0 => 'Bisha Todobaad',
        1 => 'Tod',
      ),
      'august' => 
      array (
        0 => 'Bisha Sideedaad',
        1 => 'Sid',
      ),
      'september' => 
      array (
        0 => 'Bisha Sagaalaad',
        1 => 'Sag',
      ),
      'october' => 
      array (
        0 => 'Bisha Tobnaad',
        1 => 'Tob',
      ),
      'november' => 
      array (
        0 => 'Bisha Kow iyo Tobnaad',
        1 => 'KIT',
      ),
      'december' => 
      array (
        0 => 'Bisha Laba iyo Tobnaad',
        1 => 'LIT',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Axad',
        1 => 'Axd',
      ),
      'monday' => 
      array (
        0 => 'Isniin',
        1 => 'Isn',
      ),
      'tuesday' => 
      array (
        0 => 'Talaado',
        1 => 'Tal',
      ),
      'wednesday' => 
      array (
        0 => 'Arbaco',
        1 => 'Arb',
      ),
      'friday' => 
      array (
        0 => 'Jimco',
        1 => 'Jim',
      ),
      'thursday' => 
      array (
        0 => 'Khamiis',
        1 => 'Kha',
      ),
      'saturday' => 
      array (
        0 => 'Sabti',
        1 => 'Sab',
      ),
    ),
  ),
);