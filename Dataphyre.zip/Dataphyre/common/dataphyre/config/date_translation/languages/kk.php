<?php
 $date_locale=array (
  'kk' => 
  array (
    'abstract' => 
    array (
      'today' => 'бүгін',
      'yesterday' => 'кеше',
      'two days ago' => 'екі күн бұрын',
      'in two days' => 'екі күнде',
      'last week' => 'өткен аптада',
      'last month' => 'өткен айда',
      'last year' => 'өткен жылы',
      'last decade' => 'соңғы онжылдық',
      'last century' => 'өткен ғасыр',
      'last millennial' => 'соңғы мыңжылдық',
      'at' => 'сағ',
      'of' => 'бойынша',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'қаңтар',
        1 => 'қаң.',
      ),
      'february' => 
      array (
        0 => 'ақпан',
        1 => 'ақп.',
      ),
      'march' => 
      array (
        0 => 'наурыз',
        1 => 'нау.',
      ),
      'april' => 
      array (
        0 => 'сәуір',
        1 => 'сәу.',
      ),
      'may' => 
      array (
        0 => 'мамыр',
        1 => 'мам.',
      ),
      'june' => 
      array (
        0 => 'маусым',
        1 => 'мау.',
      ),
      'july' => 
      array (
        0 => 'шілде',
        1 => 'шіл.',
      ),
      'august' => 
      array (
        0 => 'тамыз',
        1 => 'там.',
      ),
      'september' => 
      array (
        0 => 'қыркүйек',
        1 => 'қыр.',
      ),
      'october' => 
      array (
        0 => 'қазан',
        1 => 'қаз.',
      ),
      'november' => 
      array (
        0 => 'қараша',
        1 => 'қар.',
      ),
      'december' => 
      array (
        0 => 'желтоқсан',
        1 => 'жел.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'жексенбі',
        1 => 'Жс',
      ),
      'monday' => 
      array (
        0 => 'дүйсенбі',
        1 => 'Дс',
      ),
      'tuesday' => 
      array (
        0 => 'сейсенбі',
        1 => 'Сс',
      ),
      'wednesday' => 
      array (
        0 => 'сәрсенбі',
        1 => 'Ср',
      ),
      'friday' => 
      array (
        0 => 'жұма',
        1 => 'Жм',
      ),
      'thursday' => 
      array (
        0 => 'бейсенбі',
        1 => 'Бс',
      ),
      'saturday' => 
      array (
        0 => 'сенбі',
        1 => 'Сб',
      ),
    ),
  ),
);