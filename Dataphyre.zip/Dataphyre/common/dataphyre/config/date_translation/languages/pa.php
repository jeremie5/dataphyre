<?php
 $date_locale=array (
  'pa' => 
  array (
    'abstract' => 
    array (
      'today' => 'ਅੱਜ',
      'yesterday' => 'ਕੱਲ੍ਹ',
      'two days ago' => 'ਦੋ ਦਿਨ ਪਹਿਲਾਂ',
      'in two days' => 'ਦੋ ਦਿਨਾਂ ਵਿੱਚ',
      'last week' => 'ਪਿਛਲੇ ਹਫ਼ਤੇ',
      'last month' => 'ਪਿਛਲਾ ਮਹੀਨਾ',
      'last year' => 'ਪਿਛਲੇ ਸਾਲ',
      'last decade' => 'ਪਿਛਲੇ ਦਹਾਕੇ',
      'last century' => 'ਪਿਛਲੀ ਸਦੀ',
      'last millennial' => 'ਪਿਛਲੇ ਹਜ਼ਾਰ ਸਾਲ',
      'at' => '&#39;ਤੇ',
      'of' => 'ਦੇ',
      'am' => 'ਪੂ.ਦੁ.',
      'pm' => 'ਬਾ.ਦੁ.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'ਜਨਵਰੀ',
        1 => 'ਜਨ',
      ),
      'february' => 
      array (
        0 => 'ਫ਼ਰਵਰੀ',
        1 => 'ਫ਼ਰ',
      ),
      'march' => 
      array (
        0 => 'ਮਾਰਚ',
        1 => 'ਮਾਰਚ',
      ),
      'april' => 
      array (
        0 => 'ਅਪ੍ਰੈਲ',
        1 => 'ਅਪ੍ਰੈ',
      ),
      'may' => 
      array (
        0 => 'ਮਈ',
        1 => 'ਮਈ',
      ),
      'june' => 
      array (
        0 => 'ਜੂਨ',
        1 => 'ਜੂਨ',
      ),
      'july' => 
      array (
        0 => 'ਜੁਲਾਈ',
        1 => 'ਜੁਲਾ',
      ),
      'august' => 
      array (
        0 => 'ਅਗਸਤ',
        1 => 'ਅਗ',
      ),
      'september' => 
      array (
        0 => 'ਸਤੰਬਰ',
        1 => 'ਸਤੰ',
      ),
      'october' => 
      array (
        0 => 'ਅਕਤੂਬਰ',
        1 => 'ਅਕਤੂ',
      ),
      'november' => 
      array (
        0 => 'ਨਵੰਬਰ',
        1 => 'ਨਵੰ',
      ),
      'december' => 
      array (
        0 => 'ਦਸੰਬਰ',
        1 => 'ਦਸੰ',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'ਐਤਵਾਰ',
        1 => 'ਐਤ',
      ),
      'monday' => 
      array (
        0 => 'ਸੋਮਵਾਰ',
        1 => 'ਸੋਮ',
      ),
      'tuesday' => 
      array (
        0 => 'ਮੰਗਲਵਾਰ',
        1 => 'ਮੰਗਲ',
      ),
      'wednesday' => 
      array (
        0 => 'ਬੁੱਧਵਾਰ',
        1 => 'ਬੁੱਧ',
      ),
      'friday' => 
      array (
        0 => 'ਸ਼ੁੱਕਰਵਾਰ',
        1 => 'ਸ਼ੁੱਕਰ',
      ),
      'thursday' => 
      array (
        0 => 'ਵੀਰਵਾਰ',
        1 => 'ਵੀਰ',
      ),
      'saturday' => 
      array (
        0 => 'ਸ਼ਨਿੱਚਰਵਾਰ',
        1 => 'ਸ਼ਨਿੱਚਰ',
      ),
    ),
  ),
);