<?php
 $date_locale=array (
  'tt' => 
  array (
    'abstract' => 
    array (
      'today' => 'Бүген',
      'yesterday' => 'Кичә',
      'two days ago' => 'ике көн элек',
      'in two days' => 'ике көн эчендә',
      'last week' => 'узган атнада',
      'last month' => 'узган ай',
      'last year' => 'үткән елда',
      'last decade' => 'соңгы ун ел',
      'last century' => 'узган гасыр',
      'last millennial' => 'соңгы меңьеллык',
      'at' => 'at',
      'of' => 'of',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'гыйнвар',
        1 => 'гыйн.',
      ),
      'february' => 
      array (
        0 => 'февраль',
        1 => 'фев.',
      ),
      'march' => 
      array (
        0 => 'март',
        1 => 'мар.',
      ),
      'april' => 
      array (
        0 => 'апрель',
        1 => 'апр.',
      ),
      'may' => 
      array (
        0 => 'май',
        1 => 'май',
      ),
      'june' => 
      array (
        0 => 'июнь',
        1 => 'июнь',
      ),
      'july' => 
      array (
        0 => 'июль',
        1 => 'июль',
      ),
      'august' => 
      array (
        0 => 'август',
        1 => 'авг.',
      ),
      'september' => 
      array (
        0 => 'сентябрь',
        1 => 'сент.',
      ),
      'october' => 
      array (
        0 => 'октябрь',
        1 => 'окт.',
      ),
      'november' => 
      array (
        0 => 'ноябрь',
        1 => 'нояб.',
      ),
      'december' => 
      array (
        0 => 'декабрь',
        1 => 'дек.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'якшәмбе',
        1 => 'якш.',
      ),
      'monday' => 
      array (
        0 => 'дүшәмбе',
        1 => 'дүш.',
      ),
      'tuesday' => 
      array (
        0 => 'сишәмбе',
        1 => 'сиш.',
      ),
      'wednesday' => 
      array (
        0 => 'чәршәмбе',
        1 => 'чәр.',
      ),
      'friday' => 
      array (
        0 => 'җомга',
        1 => 'җом.',
      ),
      'thursday' => 
      array (
        0 => 'пәнҗешәмбе',
        1 => 'пәнҗ.',
      ),
      'saturday' => 
      array (
        0 => 'шимбә',
        1 => 'шим.',
      ),
    ),
  ),
);