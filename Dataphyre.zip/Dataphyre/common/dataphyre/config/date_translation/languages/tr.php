<?php
 $date_locale=array (
  'tr' => 
  array (
    'abstract' => 
    array (
      'today' => 'bugün',
      'yesterday' => 'dün',
      'two days ago' => 'iki gün önce',
      'in two days' => 'iki gün içinde',
      'last week' => 'geçen hafta',
      'last month' => 'geçen ay',
      'last year' => 'geçen sene',
      'last decade' => 'geçen on yıl',
      'last century' => 'geçen yüzyıl',
      'last millennial' => 'son bin yıllık',
      'at' => 'de',
      'of' => 'ile ilgili',
      'am' => 'ÖÖ',
      'pm' => 'ÖS',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Ocak',
        1 => 'Oca',
      ),
      'february' => 
      array (
        0 => 'Şubat',
        1 => 'Şub',
      ),
      'march' => 
      array (
        0 => 'Mart',
        1 => 'Mar',
      ),
      'april' => 
      array (
        0 => 'Nisan',
        1 => 'Nis',
      ),
      'may' => 
      array (
        0 => 'Mayıs',
        1 => 'May',
      ),
      'june' => 
      array (
        0 => 'Haziran',
        1 => 'Haz',
      ),
      'july' => 
      array (
        0 => 'Temmuz',
        1 => 'Tem',
      ),
      'august' => 
      array (
        0 => 'Ağustos',
        1 => 'Ağu',
      ),
      'september' => 
      array (
        0 => 'Eylül',
        1 => 'Eyl',
      ),
      'october' => 
      array (
        0 => 'Ekim',
        1 => 'Eki',
      ),
      'november' => 
      array (
        0 => 'Kasım',
        1 => 'Kas',
      ),
      'december' => 
      array (
        0 => 'Aralık',
        1 => 'Ara',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Pazar',
        1 => 'Paz',
      ),
      'monday' => 
      array (
        0 => 'Pazartesi',
        1 => 'Pzt',
      ),
      'tuesday' => 
      array (
        0 => 'Salı',
        1 => 'Sal',
      ),
      'wednesday' => 
      array (
        0 => 'Çarşamba',
        1 => 'Çar',
      ),
      'friday' => 
      array (
        0 => 'Cuma',
        1 => 'Cum',
      ),
      'thursday' => 
      array (
        0 => 'Perşembe',
        1 => 'Per',
      ),
      'saturday' => 
      array (
        0 => 'Cumartesi',
        1 => 'Cmt',
      ),
    ),
  ),
);