<?php
 $date_locale=array (
  'ne' => 
  array (
    'abstract' => 
    array (
      'today' => 'आज',
      'yesterday' => 'हिजो',
      'two days ago' => 'दुई दिन अघि',
      'in two days' => 'दुई दिनमा',
      'last week' => 'गत हप्ता',
      'last month' => 'अघिल्लो महिना',
      'last year' => 'गत वर्ष',
      'last decade' => 'पछिल्लो दशक',
      'last century' => 'पछिल्लो शताब्दी',
      'last millennial' => 'पछिल्लो सहस्राब्दी',
      'at' => 'मा',
      'of' => 'को',
      'am' => 'पूर्वाह्न',
      'pm' => 'अपराह्न',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'जनवरी',
        1 => 'जनवरी',
      ),
      'february' => 
      array (
        0 => 'फेब्रुअरी',
        1 => 'फेब्रुअरी',
      ),
      'march' => 
      array (
        0 => 'मार्च',
        1 => 'मार्च',
      ),
      'april' => 
      array (
        0 => 'अप्रिल',
        1 => 'अप्रिल',
      ),
      'may' => 
      array (
        0 => 'मे',
        1 => 'मे',
      ),
      'june' => 
      array (
        0 => 'जुन',
        1 => 'जुन',
      ),
      'july' => 
      array (
        0 => 'जुलाई',
        1 => 'जुलाई',
      ),
      'august' => 
      array (
        0 => 'अगस्ट',
        1 => 'अगस्ट',
      ),
      'september' => 
      array (
        0 => 'सेप्टेम्बर',
        1 => 'सेप्टेम्बर',
      ),
      'october' => 
      array (
        0 => 'अक्टोबर',
        1 => 'अक्टोबर',
      ),
      'november' => 
      array (
        0 => 'नोभेम्बर',
        1 => 'नोभेम्बर',
      ),
      'december' => 
      array (
        0 => 'डिसेम्बर',
        1 => 'डिसेम्बर',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'आइतबार',
        1 => 'आइत',
      ),
      'monday' => 
      array (
        0 => 'सोमबार',
        1 => 'सोम',
      ),
      'tuesday' => 
      array (
        0 => 'मङ्गलबार',
        1 => 'मङ्गल',
      ),
      'wednesday' => 
      array (
        0 => 'बुधबार',
        1 => 'बुध',
      ),
      'friday' => 
      array (
        0 => 'शुक्रबार',
        1 => 'शुक्र',
      ),
      'thursday' => 
      array (
        0 => 'बिहिबार',
        1 => 'बिहि',
      ),
      'saturday' => 
      array (
        0 => 'शनिबार',
        1 => 'शनि',
      ),
    ),
  ),
);