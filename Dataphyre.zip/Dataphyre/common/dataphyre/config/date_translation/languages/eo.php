<?php
 $date_locale=array (
  'eo' => 
  array (
    'abstract' => 
    array (
      'today' => 'hodiaŭ',
      'yesterday' => 'hieraŭ',
      'two days ago' => 'antaŭ du tagoj',
      'in two days' => 'en du tagoj',
      'last week' => 'lasta semajno',
      'last month' => 'pasintmonate',
      'last year' => 'pasintjare',
      'last decade' => 'lasta jardeko',
      'last century' => 'lasta jarcento',
      'last millennial' => 'lasta jarmilo',
      'at' => 'ĉe',
      'of' => 'de',
      'am' => 'atm',
      'pm' => 'ptm',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'januaro',
        1 => 'jan',
      ),
      'february' => 
      array (
        0 => 'februaro',
        1 => 'feb',
      ),
      'march' => 
      array (
        0 => 'marto',
        1 => 'mar',
      ),
      'april' => 
      array (
        0 => 'aprilo',
        1 => 'apr',
      ),
      'may' => 
      array (
        0 => 'majo',
        1 => 'maj',
      ),
      'june' => 
      array (
        0 => 'junio',
        1 => 'jun',
      ),
      'july' => 
      array (
        0 => 'julio',
        1 => 'jul',
      ),
      'august' => 
      array (
        0 => 'aŭgusto',
        1 => 'aŭg',
      ),
      'september' => 
      array (
        0 => 'septembro',
        1 => 'sep',
      ),
      'october' => 
      array (
        0 => 'oktobro',
        1 => 'okt',
      ),
      'november' => 
      array (
        0 => 'novembro',
        1 => 'nov',
      ),
      'december' => 
      array (
        0 => 'decembro',
        1 => 'dec',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'dimanĉo',
        1 => 'di',
      ),
      'monday' => 
      array (
        0 => 'lundo',
        1 => 'lu',
      ),
      'tuesday' => 
      array (
        0 => 'mardo',
        1 => 'ma',
      ),
      'wednesday' => 
      array (
        0 => 'merkredo',
        1 => 'me',
      ),
      'friday' => 
      array (
        0 => 'vendredo',
        1 => 've',
      ),
      'thursday' => 
      array (
        0 => 'ĵaŭdo',
        1 => 'ĵa',
      ),
      'saturday' => 
      array (
        0 => 'sabato',
        1 => 'sa',
      ),
    ),
  ),
);