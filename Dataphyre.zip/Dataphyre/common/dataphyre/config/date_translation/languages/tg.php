<?php
 $date_locale=array (
  'tg' => 
  array (
    'abstract' => 
    array (
      'today' => 'имруз',
      'yesterday' => 'дируз',
      'two days ago' => 'ду руз пеш',
      'in two days' => 'дар ду руз',
      'last week' => 'ҳафтаи гузашта',
      'last month' => 'мохи гузашта',
      'last year' => 'соли гузашта',
      'last decade' => 'даҳсолаи охир',
      'last century' => 'асри гузашта',
      'last millennial' => 'ҳазорсолаи гузашта',
      'at' => 'дар',
      'of' => 'аз',
      'am' => 'пе. чо.',
      'pm' => 'па. чо.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Январ',
        1 => 'Янв',
      ),
      'february' => 
      array (
        0 => 'Феврал',
        1 => 'Фев',
      ),
      'march' => 
      array (
        0 => 'Март',
        1 => 'Мар',
      ),
      'april' => 
      array (
        0 => 'Апрел',
        1 => 'Апр',
      ),
      'may' => 
      array (
        0 => 'Май',
        1 => 'Май',
      ),
      'june' => 
      array (
        0 => 'Июн',
        1 => 'Июн',
      ),
      'july' => 
      array (
        0 => 'Июл',
        1 => 'Июл',
      ),
      'august' => 
      array (
        0 => 'Август',
        1 => 'Авг',
      ),
      'september' => 
      array (
        0 => 'Сентябр',
        1 => 'Сен',
      ),
      'october' => 
      array (
        0 => 'Октябр',
        1 => 'Окт',
      ),
      'november' => 
      array (
        0 => 'Ноябр',
        1 => 'Ноя',
      ),
      'december' => 
      array (
        0 => 'Декабр',
        1 => 'Дек',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Якшанбе',
        1 => 'Яшб',
      ),
      'monday' => 
      array (
        0 => 'Душанбе',
        1 => 'Дшб',
      ),
      'tuesday' => 
      array (
        0 => 'Сешанбе',
        1 => 'Сшб',
      ),
      'wednesday' => 
      array (
        0 => 'Чоршанбе',
        1 => 'Чшб',
      ),
      'friday' => 
      array (
        0 => 'Ҷумъа',
        1 => 'Ҷмъ',
      ),
      'thursday' => 
      array (
        0 => 'Панҷшанбе',
        1 => 'Пшб',
      ),
      'saturday' => 
      array (
        0 => 'Шанбе',
        1 => 'Шнб',
      ),
    ),
  ),
);