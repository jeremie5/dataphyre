<?php
 $date_locale=array (
  'eu' => 
  array (
    'abstract' => 
    array (
      'today' => 'gaur',
      'yesterday' => 'atzo',
      'two days ago' => 'duela bi egun',
      'in two days' => 'bi egunetan',
      'last week' => 'lehengo astean',
      'last month' => 'azken hilabetean',
      'last year' => 'lehengo urtean',
      'last decade' => 'azken hamarkadan',
      'last century' => 'joan den mendean',
      'last millennial' => 'azken milurtekoa',
      'at' => 'etan',
      'of' => 'de',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'urtarrila',
        1 => 'urt.',
      ),
      'february' => 
      array (
        0 => 'otsaila',
        1 => 'ots.',
      ),
      'march' => 
      array (
        0 => 'martxoa',
        1 => 'mar.',
      ),
      'april' => 
      array (
        0 => 'apirila',
        1 => 'api.',
      ),
      'may' => 
      array (
        0 => 'maiatza',
        1 => 'mai.',
      ),
      'june' => 
      array (
        0 => 'ekaina',
        1 => 'eka.',
      ),
      'july' => 
      array (
        0 => 'uztaila',
        1 => 'uzt.',
      ),
      'august' => 
      array (
        0 => 'abuztua',
        1 => 'abu.',
      ),
      'september' => 
      array (
        0 => 'iraila',
        1 => 'ira.',
      ),
      'october' => 
      array (
        0 => 'urria',
        1 => 'urr.',
      ),
      'november' => 
      array (
        0 => 'azaroa',
        1 => 'aza.',
      ),
      'december' => 
      array (
        0 => 'abendua',
        1 => 'abe.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'igandea',
        1 => 'ig.',
      ),
      'monday' => 
      array (
        0 => 'astelehena',
        1 => 'al.',
      ),
      'tuesday' => 
      array (
        0 => 'asteartea',
        1 => 'ar.',
      ),
      'wednesday' => 
      array (
        0 => 'asteazkena',
        1 => 'az.',
      ),
      'friday' => 
      array (
        0 => 'ostirala',
        1 => 'or.',
      ),
      'thursday' => 
      array (
        0 => 'osteguna',
        1 => 'og.',
      ),
      'saturday' => 
      array (
        0 => 'larunbata',
        1 => 'lr.',
      ),
    ),
  ),
);