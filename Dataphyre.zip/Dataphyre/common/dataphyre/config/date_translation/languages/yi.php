<?php
 $date_locale=array (
  'yi' => 
  array (
    'abstract' => 
    array (
      'today' => 'היינט',
      'yesterday' => 'נעכטן',
      'two days ago' => 'צוויי טעג צוריק',
      'in two days' => 'אין צוויי טעג',
      'last week' => 'לעצטע וואָך',
      'last month' => 'לעצטע מאנאט',
      'last year' => 'לעצטע יאר',
      'last decade' => 'לעצטע יאָרצענדלינג',
      'last century' => 'לעצטע יאָרהונדערט',
      'last millennial' => 'לעצטע מילעניאַל',
      'at' => 'בייַ',
      'of' => 'פון',
      'am' => 'פֿאַרמיטאָג',
      'pm' => 'נאָכמיטאָג',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'יאַנואַר',
        1 => 'יאַנואַר',
      ),
      'february' => 
      array (
        0 => 'פֿעברואַר',
        1 => 'פֿעברואַר',
      ),
      'march' => 
      array (
        0 => 'מערץ',
        1 => 'מערץ',
      ),
      'april' => 
      array (
        0 => 'אַפּריל',
        1 => 'אַפּריל',
      ),
      'may' => 
      array (
        0 => 'מיי',
        1 => 'מיי',
      ),
      'june' => 
      array (
        0 => 'יוני',
        1 => 'יוני',
      ),
      'july' => 
      array (
        0 => 'יולי',
        1 => 'יולי',
      ),
      'august' => 
      array (
        0 => 'אויגוסט',
        1 => 'אויגוסט',
      ),
      'september' => 
      array (
        0 => 'סעפּטעמבער',
        1 => 'סעפּטעמבער',
      ),
      'october' => 
      array (
        0 => 'אקטאבער',
        1 => 'אקטאבער',
      ),
      'november' => 
      array (
        0 => 'נאוועמבער',
        1 => 'נאוועמבער',
      ),
      'december' => 
      array (
        0 => 'דעצעמבער',
        1 => 'דעצעמבער',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'זונטיק',
        1 => 'זונטיק',
      ),
      'monday' => 
      array (
        0 => 'מאָנטיק',
        1 => 'מאָנטיק',
      ),
      'tuesday' => 
      array (
        0 => 'דינסטיק',
        1 => 'דינסטיק',
      ),
      'wednesday' => 
      array (
        0 => 'מיטוואך',
        1 => 'מיטוואך',
      ),
      'friday' => 
      array (
        0 => 'פֿרײַטיק',
        1 => 'פֿרײַטיק',
      ),
      'thursday' => 
      array (
        0 => 'דאנערשטיק',
        1 => 'דאנערשטיק',
      ),
      'saturday' => 
      array (
        0 => 'שבת',
        1 => 'שבת',
      ),
    ),
  ),
);