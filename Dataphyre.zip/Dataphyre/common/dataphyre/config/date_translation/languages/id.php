<?php
 $date_locale=array (
  'id' => 
  array (
    'abstract' => 
    array (
      'today' => 'hari ini',
      'yesterday' => 'kemarin',
      'two days ago' => 'dua hari yang lalu',
      'in two days' => 'dalam dua hari',
      'last week' => 'minggu lalu',
      'last month' => 'bulan lalu',
      'last year' => 'tahun lalu',
      'last decade' => 'dekade terakhir',
      'last century' => 'abad terakhir',
      'last millennial' => 'milenial terakhir',
      'at' => 'pada',
      'of' => 'dari',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Januari',
        1 => 'Jan',
      ),
      'february' => 
      array (
        0 => 'Februari',
        1 => 'Feb',
      ),
      'march' => 
      array (
        0 => 'Maret',
        1 => 'Mar',
      ),
      'april' => 
      array (
        0 => 'April',
        1 => 'Apr',
      ),
      'may' => 
      array (
        0 => 'Mei',
        1 => 'Mei',
      ),
      'june' => 
      array (
        0 => 'Juni',
        1 => 'Jun',
      ),
      'july' => 
      array (
        0 => 'Juli',
        1 => 'Jul',
      ),
      'august' => 
      array (
        0 => 'Agustus',
        1 => 'Agt',
      ),
      'september' => 
      array (
        0 => 'September',
        1 => 'Sep',
      ),
      'october' => 
      array (
        0 => 'Oktober',
        1 => 'Okt',
      ),
      'november' => 
      array (
        0 => 'November',
        1 => 'Nov',
      ),
      'december' => 
      array (
        0 => 'Desember',
        1 => 'Des',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Minggu',
        1 => 'Min',
      ),
      'monday' => 
      array (
        0 => 'Senin',
        1 => 'Sen',
      ),
      'tuesday' => 
      array (
        0 => 'Selasa',
        1 => 'Sel',
      ),
      'wednesday' => 
      array (
        0 => 'Rabu',
        1 => 'Rab',
      ),
      'friday' => 
      array (
        0 => 'Jumat',
        1 => 'Jum',
      ),
      'thursday' => 
      array (
        0 => 'Kamis',
        1 => 'Kam',
      ),
      'saturday' => 
      array (
        0 => 'Sabtu',
        1 => 'Sab',
      ),
    ),
  ),
);