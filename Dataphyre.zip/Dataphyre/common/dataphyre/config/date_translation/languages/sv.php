<?php
 $date_locale=array (
  'sv' => 
  array (
    'abstract' => 
    array (
      'today' => 'i dag',
      'yesterday' => 'i går',
      'two days ago' => 'två dagar sedan',
      'in two days' => 'om två dagar',
      'last week' => 'förra veckan',
      'last month' => 'förra månaden',
      'last year' => 'förra året',
      'last decade' => 'senaste decenniet',
      'last century' => 'förra århundradet',
      'last millennial' => 'förra årtusendet',
      'at' => 'på',
      'of' => 'av',
      'am' => 'fm',
      'pm' => 'em',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'januari',
        1 => 'jan.',
      ),
      'february' => 
      array (
        0 => 'februari',
        1 => 'feb.',
      ),
      'march' => 
      array (
        0 => 'mars',
        1 => 'mars',
      ),
      'april' => 
      array (
        0 => 'april',
        1 => 'apr.',
      ),
      'may' => 
      array (
        0 => 'maj',
        1 => 'maj',
      ),
      'june' => 
      array (
        0 => 'juni',
        1 => 'juni',
      ),
      'july' => 
      array (
        0 => 'juli',
        1 => 'juli',
      ),
      'august' => 
      array (
        0 => 'augusti',
        1 => 'aug.',
      ),
      'september' => 
      array (
        0 => 'september',
        1 => 'sep.',
      ),
      'october' => 
      array (
        0 => 'oktober',
        1 => 'okt.',
      ),
      'november' => 
      array (
        0 => 'november',
        1 => 'nov.',
      ),
      'december' => 
      array (
        0 => 'december',
        1 => 'dec.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'söndag',
        1 => 'sön',
      ),
      'monday' => 
      array (
        0 => 'måndag',
        1 => 'mån',
      ),
      'tuesday' => 
      array (
        0 => 'tisdag',
        1 => 'tis',
      ),
      'wednesday' => 
      array (
        0 => 'onsdag',
        1 => 'ons',
      ),
      'friday' => 
      array (
        0 => 'fredag',
        1 => 'fre',
      ),
      'thursday' => 
      array (
        0 => 'torsdag',
        1 => 'tors',
      ),
      'saturday' => 
      array (
        0 => 'lördag',
        1 => 'lör',
      ),
    ),
  ),
);