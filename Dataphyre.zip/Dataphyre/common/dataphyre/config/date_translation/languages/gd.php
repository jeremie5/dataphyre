<?php
 $date_locale=array (
  'gd' => 
  array (
    'abstract' => 
    array (
      'today' => 'an diugh',
      'yesterday' => 'an dè',
      'two days ago' => 'dà latha air ais',
      'in two days' => 'ann an dà latha',
      'last week' => 'seachdainn seo chaidh',
      'last month' => 'mìos a chaidh seachad',
      'last year' => 'an-uiridh',
      'last decade' => 'deichead mu dheireadh',
      'last century' => 'linn mu dheireadh',
      'last millennial' => 'mìle bliadhna mu dheireadh',
      'at' => 'aig',
      'of' => 'à',
      'am' => 'm',
      'pm' => 'f',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'dhen Fhaoilleach',
        1 => 'Faoi',
      ),
      'february' => 
      array (
        0 => 'dhen Ghearran',
        1 => 'Gearr',
      ),
      'march' => 
      array (
        0 => 'dhen Mhàrt',
        1 => 'Màrt',
      ),
      'april' => 
      array (
        0 => 'dhen Ghiblean',
        1 => 'Gibl',
      ),
      'may' => 
      array (
        0 => 'dhen Chèitean',
        1 => 'Cèit',
      ),
      'june' => 
      array (
        0 => 'dhen Ògmhios',
        1 => 'Ògmh',
      ),
      'july' => 
      array (
        0 => 'dhen Iuchar',
        1 => 'Iuch',
      ),
      'august' => 
      array (
        0 => 'dhen Lùnastal',
        1 => 'Lùna',
      ),
      'september' => 
      array (
        0 => 'dhen t-Sultain',
        1 => 'Sult',
      ),
      'october' => 
      array (
        0 => 'dhen Dàmhair',
        1 => 'Dàmh',
      ),
      'november' => 
      array (
        0 => 'dhen t-Samhain',
        1 => 'Samh',
      ),
      'december' => 
      array (
        0 => 'dhen Dùbhlachd',
        1 => 'Dùbh',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'DiDòmhnaich',
        1 => 'DiD',
      ),
      'monday' => 
      array (
        0 => 'DiLuain',
        1 => 'DiL',
      ),
      'tuesday' => 
      array (
        0 => 'DiMàirt',
        1 => 'DiM',
      ),
      'wednesday' => 
      array (
        0 => 'DiCiadain',
        1 => 'DiC',
      ),
      'friday' => 
      array (
        0 => 'DihAoine',
        1 => 'Dih',
      ),
      'thursday' => 
      array (
        0 => 'DiarDaoin',
        1 => 'Dia',
      ),
      'saturday' => 
      array (
        0 => 'DiSathairne',
        1 => 'DiS',
      ),
    ),
  ),
);