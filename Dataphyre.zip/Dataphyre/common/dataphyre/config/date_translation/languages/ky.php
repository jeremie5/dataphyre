<?php
 $date_locale=array (
  'ky' => 
  array (
    'abstract' => 
    array (
      'today' => 'бүгүн',
      'yesterday' => 'кечээ',
      'two days ago' => 'эки күн мурун',
      'in two days' => 'эки күндө',
      'last week' => 'акыркы жума',
      'last month' => 'өткөн айда',
      'last year' => 'Өткөн жылы',
      'last decade' => 'акыркы он жылдык',
      'last century' => 'өткөн кылым',
      'last millennial' => 'акыркы миң жылдык',
      'at' => 'саат',
      'of' => 'нын',
      'am' => 'таңкы',
      'pm' => 'түштөн кийинки',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'январь',
        1 => 'янв.',
      ),
      'february' => 
      array (
        0 => 'февраль',
        1 => 'фев.',
      ),
      'march' => 
      array (
        0 => 'март',
        1 => 'мар.',
      ),
      'april' => 
      array (
        0 => 'апрель',
        1 => 'апр.',
      ),
      'may' => 
      array (
        0 => 'май',
        1 => 'май',
      ),
      'june' => 
      array (
        0 => 'июнь',
        1 => 'июн.',
      ),
      'july' => 
      array (
        0 => 'июль',
        1 => 'июл.',
      ),
      'august' => 
      array (
        0 => 'август',
        1 => 'авг.',
      ),
      'september' => 
      array (
        0 => 'сентябрь',
        1 => 'сен.',
      ),
      'october' => 
      array (
        0 => 'октябрь',
        1 => 'окт.',
      ),
      'november' => 
      array (
        0 => 'ноябрь',
        1 => 'ноя.',
      ),
      'december' => 
      array (
        0 => 'декабрь',
        1 => 'дек.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'жекшемби',
        1 => 'жек.',
      ),
      'monday' => 
      array (
        0 => 'дүйшөмбү',
        1 => 'дүй.',
      ),
      'tuesday' => 
      array (
        0 => 'шейшемби',
        1 => 'шейш.',
      ),
      'wednesday' => 
      array (
        0 => 'шаршемби',
        1 => 'шарш.',
      ),
      'friday' => 
      array (
        0 => 'жума',
        1 => 'жума',
      ),
      'thursday' => 
      array (
        0 => 'бейшемби',
        1 => 'бейш.',
      ),
      'saturday' => 
      array (
        0 => 'ишемби',
        1 => 'ишм.',
      ),
    ),
  ),
);