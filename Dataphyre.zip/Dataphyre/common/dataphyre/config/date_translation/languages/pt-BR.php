<?php
 $date_locale=array (
  'pt-BR' => 
  array (
    'abstract' => 
    array (
      'today' => 'hoje',
      'yesterday' => 'ontem',
      'two days ago' => 'dois dias atrás',
      'in two days' => 'em dois dias',
      'last week' => 'semana anterior',
      'last month' => 'mês passado',
      'last year' => 'ano passado',
      'last decade' => 'última década',
      'last century' => 'século passado',
      'last millennial' => 'último milênio',
      'at' => 'no',
      'of' => 'de',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'janeiro',
        1 => 'jan',
      ),
      'february' => 
      array (
        0 => 'fevereiro',
        1 => 'fev',
      ),
      'march' => 
      array (
        0 => 'março',
        1 => 'mar',
      ),
      'april' => 
      array (
        0 => 'abril',
        1 => 'abr',
      ),
      'may' => 
      array (
        0 => 'maio',
        1 => 'mai',
      ),
      'june' => 
      array (
        0 => 'junho',
        1 => 'jun',
      ),
      'july' => 
      array (
        0 => 'julho',
        1 => 'jul',
      ),
      'august' => 
      array (
        0 => 'agosto',
        1 => 'ago',
      ),
      'september' => 
      array (
        0 => 'setembro',
        1 => 'set',
      ),
      'october' => 
      array (
        0 => 'outubro',
        1 => 'out',
      ),
      'november' => 
      array (
        0 => 'novembro',
        1 => 'nov',
      ),
      'december' => 
      array (
        0 => 'dezembro',
        1 => 'dez',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'domingo',
        1 => 'dom',
      ),
      'monday' => 
      array (
        0 => 'segunda-feira',
        1 => 'seg',
      ),
      'tuesday' => 
      array (
        0 => 'terça-feira',
        1 => 'ter',
      ),
      'wednesday' => 
      array (
        0 => 'quarta-feira',
        1 => 'qua',
      ),
      'friday' => 
      array (
        0 => 'sexta-feira',
        1 => 'sex',
      ),
      'thursday' => 
      array (
        0 => 'quinta-feira',
        1 => 'qui',
      ),
      'saturday' => 
      array (
        0 => 'sábado',
        1 => 'sáb',
      ),
    ),
  ),
);