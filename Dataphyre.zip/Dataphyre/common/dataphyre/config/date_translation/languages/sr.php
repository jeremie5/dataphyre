<?php
 $date_locale=array (
  'sr' => 
  array (
    'abstract' => 
    array (
      'today' => 'данас',
      'yesterday' => 'јуче',
      'two days ago' => 'Пре два дана',
      'in two days' => 'за два дана',
      'last week' => 'Прошле недеље',
      'last month' => 'прошлог месеца',
      'last year' => 'прошле године',
      'last decade' => 'Последња деценија',
      'last century' => 'прошлог века',
      'last millennial' => 'прошлог миленијума',
      'at' => 'ат',
      'of' => 'оф',
      'am' => 'пре подне',
      'pm' => 'по подне',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'јануар',
        1 => 'јан',
      ),
      'february' => 
      array (
        0 => 'фебруар',
        1 => 'феб',
      ),
      'march' => 
      array (
        0 => 'март',
        1 => 'мар',
      ),
      'april' => 
      array (
        0 => 'април',
        1 => 'апр',
      ),
      'may' => 
      array (
        0 => 'мај',
        1 => 'мај',
      ),
      'june' => 
      array (
        0 => 'јун',
        1 => 'јун',
      ),
      'july' => 
      array (
        0 => 'јул',
        1 => 'јул',
      ),
      'august' => 
      array (
        0 => 'август',
        1 => 'авг',
      ),
      'september' => 
      array (
        0 => 'септембар',
        1 => 'сеп',
      ),
      'october' => 
      array (
        0 => 'октобар',
        1 => 'окт',
      ),
      'november' => 
      array (
        0 => 'новембар',
        1 => 'нов',
      ),
      'december' => 
      array (
        0 => 'децембар',
        1 => 'дец',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'недеља',
        1 => 'нед',
      ),
      'monday' => 
      array (
        0 => 'понедељак',
        1 => 'пон',
      ),
      'tuesday' => 
      array (
        0 => 'уторак',
        1 => 'уто',
      ),
      'wednesday' => 
      array (
        0 => 'среда',
        1 => 'сре',
      ),
      'friday' => 
      array (
        0 => 'петак',
        1 => 'пет',
      ),
      'thursday' => 
      array (
        0 => 'четвртак',
        1 => 'чет',
      ),
      'saturday' => 
      array (
        0 => 'субота',
        1 => 'суб',
      ),
    ),
  ),
);