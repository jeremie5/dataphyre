<?php
 $date_locale=array (
  'ga' => 
  array (
    'abstract' => 
    array (
      'today' => 'inniu',
      'yesterday' => 'inné',
      'two days ago' => 'dhá lá ó shin',
      'in two days' => 'i dhá lá',
      'last week' => 'tseachtain seo caite',
      'last month' => 'an mhí seo caite',
      'last year' => 'anuraidh',
      'last decade' => 'deich mbliana anuas',
      'last century' => 'haois seo caite',
      'last millennial' => 'millennial seo caite',
      'at' => 'ag',
      'of' => 'de',
      'am' => 'r.n.',
      'pm' => 'i.n.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Eanáir',
        1 => 'Ean',
      ),
      'february' => 
      array (
        0 => 'Feabhra',
        1 => 'Feabh',
      ),
      'march' => 
      array (
        0 => 'Márta',
        1 => 'Márta',
      ),
      'april' => 
      array (
        0 => 'Aibreán',
        1 => 'Aib',
      ),
      'may' => 
      array (
        0 => 'Bealtaine',
        1 => 'Beal',
      ),
      'june' => 
      array (
        0 => 'Meitheamh',
        1 => 'Meith',
      ),
      'july' => 
      array (
        0 => 'Iúil',
        1 => 'Iúil',
      ),
      'august' => 
      array (
        0 => 'Lúnasa',
        1 => 'Lún',
      ),
      'september' => 
      array (
        0 => 'Meán Fómhair',
        1 => 'MFómh',
      ),
      'october' => 
      array (
        0 => 'Deireadh Fómhair',
        1 => 'DFómh',
      ),
      'november' => 
      array (
        0 => 'Samhain',
        1 => 'Samh',
      ),
      'december' => 
      array (
        0 => 'Nollaig',
        1 => 'Noll',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Dé Domhnaigh',
        1 => 'Domh',
      ),
      'monday' => 
      array (
        0 => 'Dé Luain',
        1 => 'Luan',
      ),
      'tuesday' => 
      array (
        0 => 'Dé Máirt',
        1 => 'Máirt',
      ),
      'wednesday' => 
      array (
        0 => 'Dé Céadaoin',
        1 => 'Céad',
      ),
      'friday' => 
      array (
        0 => 'Dé hAoine',
        1 => 'Aoine',
      ),
      'thursday' => 
      array (
        0 => 'Déardaoin',
        1 => 'Déar',
      ),
      'saturday' => 
      array (
        0 => 'Dé Sathairn',
        1 => 'Sath',
      ),
    ),
  ),
);