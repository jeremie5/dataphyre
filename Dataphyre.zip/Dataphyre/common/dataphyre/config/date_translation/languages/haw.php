<?php
 $date_locale=array (
  'haw' => 
  array (
    'abstract' => 
    array (
      'today' => 'i kēia lā',
      'yesterday' => 'i nehinei',
      'two days ago' => 'ʻelua lā aku nei',
      'in two days' => 'i nā lā ʻelua',
      'last week' => 'i ka pule aku nei',
      'last month' => 'mahina i hala',
      'last year' => 'i ka makahiki aku nei',
      'last decade' => 'he ʻumi makahiki i hala',
      'last century' => 'ke kenekulia i hala',
      'last millennial' => 'milenio hope loa',
      'at' => 'ma',
      'of' => 'o',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Ianuali',
        1 => 'Ian.',
      ),
      'february' => 
      array (
        0 => 'Pepeluali',
        1 => 'Pep.',
      ),
      'march' => 
      array (
        0 => 'Malaki',
        1 => 'Mal.',
      ),
      'april' => 
      array (
        0 => 'ʻApelila',
        1 => 'ʻAp.',
      ),
      'may' => 
      array (
        0 => 'Mei',
        1 => 'Mei',
      ),
      'june' => 
      array (
        0 => 'Iune',
        1 => 'Iun.',
      ),
      'july' => 
      array (
        0 => 'Iulai',
        1 => 'Iul.',
      ),
      'august' => 
      array (
        0 => 'ʻAukake',
        1 => 'ʻAu.',
      ),
      'september' => 
      array (
        0 => 'Kepakemapa',
        1 => 'Kep.',
      ),
      'october' => 
      array (
        0 => 'ʻOkakopa',
        1 => 'ʻOk.',
      ),
      'november' => 
      array (
        0 => 'Nowemapa',
        1 => 'Now.',
      ),
      'december' => 
      array (
        0 => 'Kekemapa',
        1 => 'Kek.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Lāpule',
        1 => 'LP',
      ),
      'monday' => 
      array (
        0 => 'Poʻakahi',
        1 => 'P1',
      ),
      'tuesday' => 
      array (
        0 => 'Poʻalua',
        1 => 'P2',
      ),
      'wednesday' => 
      array (
        0 => 'Poʻakolu',
        1 => 'P3',
      ),
      'friday' => 
      array (
        0 => 'Poʻalima',
        1 => 'P5',
      ),
      'thursday' => 
      array (
        0 => 'Poʻahā',
        1 => 'P4',
      ),
      'saturday' => 
      array (
        0 => 'Poʻaono',
        1 => 'P6',
      ),
    ),
  ),
);