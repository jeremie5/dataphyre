<?php
 $date_locale=array (
  'et' => 
  array (
    'abstract' => 
    array (
      'today' => 'täna',
      'yesterday' => 'eile',
      'two days ago' => 'kaks päeva tagasi',
      'in two days' => 'kahe päeva pärast',
      'last week' => 'eelmine nädal',
      'last month' => 'eelmine kuu',
      'last year' => 'eelmisel aastal',
      'last decade' => 'eelmisel kümnendil',
      'last century' => 'eelmisel sajandil',
      'last millennial' => 'möödunud aastatuhande',
      'at' => 'juures',
      'of' => 'kohta',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'jaanuar',
        1 => 'jaan',
      ),
      'february' => 
      array (
        0 => 'veebruar',
        1 => 'veebr',
      ),
      'march' => 
      array (
        0 => 'märts',
        1 => 'märts',
      ),
      'april' => 
      array (
        0 => 'aprill',
        1 => 'apr',
      ),
      'may' => 
      array (
        0 => 'mai',
        1 => 'mai',
      ),
      'june' => 
      array (
        0 => 'juuni',
        1 => 'juuni',
      ),
      'july' => 
      array (
        0 => 'juuli',
        1 => 'juuli',
      ),
      'august' => 
      array (
        0 => 'august',
        1 => 'aug',
      ),
      'september' => 
      array (
        0 => 'september',
        1 => 'sept',
      ),
      'october' => 
      array (
        0 => 'oktoober',
        1 => 'okt',
      ),
      'november' => 
      array (
        0 => 'november',
        1 => 'nov',
      ),
      'december' => 
      array (
        0 => 'detsember',
        1 => 'dets',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'pühapäev',
        1 => 'P',
      ),
      'monday' => 
      array (
        0 => 'esmaspäev',
        1 => 'E',
      ),
      'tuesday' => 
      array (
        0 => 'teisipäev',
        1 => 'T',
      ),
      'wednesday' => 
      array (
        0 => 'kolmapäev',
        1 => 'K',
      ),
      'friday' => 
      array (
        0 => 'reede',
        1 => 'R',
      ),
      'thursday' => 
      array (
        0 => 'neljapäev',
        1 => 'N',
      ),
      'saturday' => 
      array (
        0 => 'laupäev',
        1 => 'L',
      ),
    ),
  ),
);