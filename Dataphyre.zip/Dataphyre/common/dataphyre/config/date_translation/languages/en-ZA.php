<?php
 $date_locale=array (
  'en-ZA' => 
  array (
    'abstract' => 
    array (
      'today' => '',
      'yesterday' => '',
      'two days ago' => '',
      'in two days' => '',
      'last week' => '',
      'last month' => '',
      'last year' => '',
      'last decade' => '',
      'last century' => '',
      'last millennial' => '',
      'at' => '',
      'of' => '',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'January',
        1 => 'Jan',
      ),
      'february' => 
      array (
        0 => 'February',
        1 => 'Feb',
      ),
      'march' => 
      array (
        0 => 'March',
        1 => 'Mar',
      ),
      'april' => 
      array (
        0 => 'April',
        1 => 'Apr',
      ),
      'may' => 
      array (
        0 => 'May',
        1 => 'May',
      ),
      'june' => 
      array (
        0 => 'June',
        1 => 'Jun',
      ),
      'july' => 
      array (
        0 => 'July',
        1 => 'Jul',
      ),
      'august' => 
      array (
        0 => 'August',
        1 => 'Aug',
      ),
      'september' => 
      array (
        0 => 'September',
        1 => 'Sep',
      ),
      'october' => 
      array (
        0 => 'October',
        1 => 'Oct',
      ),
      'november' => 
      array (
        0 => 'November',
        1 => 'Nov',
      ),
      'december' => 
      array (
        0 => 'December',
        1 => 'Dec',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Sunday',
        1 => 'Sun',
      ),
      'monday' => 
      array (
        0 => 'Monday',
        1 => 'Mon',
      ),
      'tuesday' => 
      array (
        0 => 'Tuesday',
        1 => 'Tue',
      ),
      'wednesday' => 
      array (
        0 => 'Wednesday',
        1 => 'Wed',
      ),
      'friday' => 
      array (
        0 => 'Friday',
        1 => 'Fri',
      ),
      'thursday' => 
      array (
        0 => 'Thursday',
        1 => 'Thu',
      ),
      'saturday' => 
      array (
        0 => 'Saturday',
        1 => 'Sat',
      ),
    ),
  ),
);