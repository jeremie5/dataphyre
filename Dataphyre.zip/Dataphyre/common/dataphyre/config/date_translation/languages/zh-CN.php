<?php
 $date_locale=array (
  'zh-CN' => 
  array (
    'abstract' => 
    array (
      'today' => '今天',
      'yesterday' => '昨天',
      'two days ago' => '两天前',
      'in two days' => '在两天',
      'last week' => '上个星期',
      'last month' => '上个月',
      'last year' => '去年',
      'last decade' => '过去十年',
      'last century' => '上世纪',
      'last millennial' => '上个千禧一代',
      'at' => '在',
      'of' => '的',
      'am' => '上午',
      'pm' => '下午',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => '一月',
        1 => '1月',
      ),
      'february' => 
      array (
        0 => '二月',
        1 => '2月',
      ),
      'march' => 
      array (
        0 => '三月',
        1 => '3月',
      ),
      'april' => 
      array (
        0 => '四月',
        1 => '4月',
      ),
      'may' => 
      array (
        0 => '五月',
        1 => '5月',
      ),
      'june' => 
      array (
        0 => '六月',
        1 => '6月',
      ),
      'july' => 
      array (
        0 => '七月',
        1 => '7月',
      ),
      'august' => 
      array (
        0 => '八月',
        1 => '8月',
      ),
      'september' => 
      array (
        0 => '九月',
        1 => '9月',
      ),
      'october' => 
      array (
        0 => '十月',
        1 => '10月',
      ),
      'november' => 
      array (
        0 => '十一月',
        1 => '11月',
      ),
      'december' => 
      array (
        0 => '十二月',
        1 => '12月',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => '星期日',
        1 => '周日',
      ),
      'monday' => 
      array (
        0 => '星期一',
        1 => '周一',
      ),
      'tuesday' => 
      array (
        0 => '星期二',
        1 => '周二',
      ),
      'wednesday' => 
      array (
        0 => '星期三',
        1 => '周三',
      ),
      'friday' => 
      array (
        0 => '星期五',
        1 => '周五',
      ),
      'thursday' => 
      array (
        0 => '星期四',
        1 => '周四',
      ),
      'saturday' => 
      array (
        0 => '星期六',
        1 => '周六',
      ),
    ),
  ),
);