<?php
 $date_locale=array (
  'ckb' => 
  array (
    'abstract' => 
    array (
      'today' => 'ئەمڕۆ',
      'yesterday' => 'دوێنێ',
      'two days ago' => 'دوو ڕۆژ لە مەوبەر',
      'in two days' => 'لە دوو ڕۆژ دا',
      'last week' => 'هەفتەی ڕابردوو',
      'last month' => 'مانگی ڕابردوو',
      'last year' => 'پار',
      'last decade' => 'دەیەی ڕابردوو',
      'last century' => 'سەدەی ڕابردوو',
      'last millennial' => 'هەزارەی ڕابردوو',
      'at' => 'لە',
      'of' => 'لە',
      'am' => 'ب.ن',
      'pm' => 'د.ن',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'کانوونی دووەم',
        1 => 'کانوونی دووەم',
      ),
      'february' => 
      array (
        0 => 'شوبات',
        1 => 'شوبات',
      ),
      'march' => 
      array (
        0 => 'ئازار',
        1 => 'ئازار',
      ),
      'april' => 
      array (
        0 => 'نیسان',
        1 => 'نیسان',
      ),
      'may' => 
      array (
        0 => 'ئایار',
        1 => 'ئایار',
      ),
      'june' => 
      array (
        0 => 'حوزەیران',
        1 => 'حوزەیران',
      ),
      'july' => 
      array (
        0 => 'تەمووز',
        1 => 'تەمووز',
      ),
      'august' => 
      array (
        0 => 'ئاب',
        1 => 'ئاب',
      ),
      'september' => 
      array (
        0 => 'ئەیلوول',
        1 => 'ئەیلوول',
      ),
      'october' => 
      array (
        0 => 'تشرینی یەکەم',
        1 => 'تشرینی یەکەم',
      ),
      'november' => 
      array (
        0 => 'تشرینی دووەم',
        1 => 'تشرینی دووەم',
      ),
      'december' => 
      array (
        0 => 'کانونی یەکەم',
        1 => 'کانونی یەکەم',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'یەکشەممە',
        1 => 'یەکشەممە',
      ),
      'monday' => 
      array (
        0 => 'دووشەممە',
        1 => 'دووشەممە',
      ),
      'tuesday' => 
      array (
        0 => 'سێشەممە',
        1 => 'سێشەممە',
      ),
      'wednesday' => 
      array (
        0 => 'چوارشەممە',
        1 => 'چوارشەممە',
      ),
      'friday' => 
      array (
        0 => 'ھەینی',
        1 => 'ھەینی',
      ),
      'thursday' => 
      array (
        0 => 'پێنجشەممە',
        1 => 'پێنجشەممە',
      ),
      'saturday' => 
      array (
        0 => 'شەممە',
        1 => 'شەممە',
      ),
    ),
  ),
);