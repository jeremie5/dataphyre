<?php
 $date_locale=array (
  'fil' => 
  array (
    'abstract' => 
    array (
      'today' => 'ngayon',
      'yesterday' => 'kahapon',
      'two days ago' => 'dalawang araw na nakalipas',
      'in two days' => 'sa dalawang araw',
      'last week' => 'nakaraang linggo',
      'last month' => 'noong nakaraang buwan',
      'last year' => 'noong nakaraang taon',
      'last decade' => 'nung nakaraang dekada',
      'last century' => 'noong nakaraang siglo',
      'last millennial' => 'huling millennial',
      'at' => 'sa',
      'of' => 'ng',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Enero',
        1 => 'Ene',
      ),
      'february' => 
      array (
        0 => 'Pebrero',
        1 => 'Peb',
      ),
      'march' => 
      array (
        0 => 'Marso',
        1 => 'Mar',
      ),
      'april' => 
      array (
        0 => 'Abril',
        1 => 'Abr',
      ),
      'may' => 
      array (
        0 => 'Mayo',
        1 => 'May',
      ),
      'june' => 
      array (
        0 => 'Hunyo',
        1 => 'Hun',
      ),
      'july' => 
      array (
        0 => 'Hulyo',
        1 => 'Hul',
      ),
      'august' => 
      array (
        0 => 'Agosto',
        1 => 'Ago',
      ),
      'september' => 
      array (
        0 => 'Setyembre',
        1 => 'Set',
      ),
      'october' => 
      array (
        0 => 'Oktubre',
        1 => 'Okt',
      ),
      'november' => 
      array (
        0 => 'Nobyembre',
        1 => 'Nob',
      ),
      'december' => 
      array (
        0 => 'Disyembre',
        1 => 'Dis',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Linggo',
        1 => 'Lin',
      ),
      'monday' => 
      array (
        0 => 'Lunes',
        1 => 'Lun',
      ),
      'tuesday' => 
      array (
        0 => 'Martes',
        1 => 'Mar',
      ),
      'wednesday' => 
      array (
        0 => 'Miyerkules',
        1 => 'Miy',
      ),
      'friday' => 
      array (
        0 => 'Biyernes',
        1 => 'Biy',
      ),
      'thursday' => 
      array (
        0 => 'Huwebes',
        1 => 'Huw',
      ),
      'saturday' => 
      array (
        0 => 'Sabado',
        1 => 'Sab',
      ),
    ),
  ),
);