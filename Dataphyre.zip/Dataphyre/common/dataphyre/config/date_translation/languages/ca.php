<?php
 $date_locale=array (
  'ca' => 
  array (
    'abstract' => 
    array (
      'today' => 'avui',
      'yesterday' => 'ahir',
      'two days ago' => 'fa dos dies',
      'in two days' => 'en dos dies',
      'last week' => 'la setmana passada',
      'last month' => 'el mes passat',
      'last year' => 'l&#39;any passat',
      'last decade' => 'darrera dècada',
      'last century' => 'segle passat',
      'last millennial' => 'darrer mil·lenari',
      'at' => 'a les',
      'of' => 'de',
      'am' => 'a. m.',
      'pm' => 'p. m.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'de gener',
        1 => 'de gen.',
      ),
      'february' => 
      array (
        0 => 'de febrer',
        1 => 'de febr.',
      ),
      'march' => 
      array (
        0 => 'de març',
        1 => 'de març',
      ),
      'april' => 
      array (
        0 => 'd’abril',
        1 => 'd’abr.',
      ),
      'may' => 
      array (
        0 => 'de maig',
        1 => 'de maig',
      ),
      'june' => 
      array (
        0 => 'de juny',
        1 => 'de juny',
      ),
      'july' => 
      array (
        0 => 'de juliol',
        1 => 'de jul.',
      ),
      'august' => 
      array (
        0 => 'd’agost',
        1 => 'd’ag.',
      ),
      'september' => 
      array (
        0 => 'de setembre',
        1 => 'de set.',
      ),
      'october' => 
      array (
        0 => 'd’octubre',
        1 => 'd’oct.',
      ),
      'november' => 
      array (
        0 => 'de novembre',
        1 => 'de nov.',
      ),
      'december' => 
      array (
        0 => 'de desembre',
        1 => 'de des.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'diumenge',
        1 => 'dg.',
      ),
      'monday' => 
      array (
        0 => 'dilluns',
        1 => 'dl.',
      ),
      'tuesday' => 
      array (
        0 => 'dimarts',
        1 => 'dt.',
      ),
      'wednesday' => 
      array (
        0 => 'dimecres',
        1 => 'dc.',
      ),
      'friday' => 
      array (
        0 => 'divendres',
        1 => 'dv.',
      ),
      'thursday' => 
      array (
        0 => 'dijous',
        1 => 'dj.',
      ),
      'saturday' => 
      array (
        0 => 'dissabte',
        1 => 'ds.',
      ),
    ),
  ),
);