<?php
 $date_locale=array (
  'lt' => 
  array (
    'abstract' => 
    array (
      'today' => 'šiandien',
      'yesterday' => 'vakar',
      'two days ago' => 'prieš dvi dienas',
      'in two days' => 'per dvi dienas',
      'last week' => 'praeitą savaitę',
      'last month' => 'praeitą mėnesį',
      'last year' => 'praeitais metais',
      'last decade' => 'praėjusį dešimtmetį',
      'last century' => 'praėjusį šimtmetį',
      'last millennial' => 'praėjusį tūkstantmetį',
      'at' => 'adresu',
      'of' => 'apie',
      'am' => 'priešpiet',
      'pm' => 'popiet',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'sausio',
        1 => 'saus.',
      ),
      'february' => 
      array (
        0 => 'vasario',
        1 => 'vas.',
      ),
      'march' => 
      array (
        0 => 'kovo',
        1 => 'kov.',
      ),
      'april' => 
      array (
        0 => 'balandžio',
        1 => 'bal.',
      ),
      'may' => 
      array (
        0 => 'gegužės',
        1 => 'geg.',
      ),
      'june' => 
      array (
        0 => 'birželio',
        1 => 'birž.',
      ),
      'july' => 
      array (
        0 => 'liepos',
        1 => 'liep.',
      ),
      'august' => 
      array (
        0 => 'rugpjūčio',
        1 => 'rugp.',
      ),
      'september' => 
      array (
        0 => 'rugsėjo',
        1 => 'rugs.',
      ),
      'october' => 
      array (
        0 => 'spalio',
        1 => 'spal.',
      ),
      'november' => 
      array (
        0 => 'lapkričio',
        1 => 'lapkr.',
      ),
      'december' => 
      array (
        0 => 'gruodžio',
        1 => 'gruod.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'sekmadienis',
        1 => 'sk',
      ),
      'monday' => 
      array (
        0 => 'pirmadienis',
        1 => 'pr',
      ),
      'tuesday' => 
      array (
        0 => 'antradienis',
        1 => 'an',
      ),
      'wednesday' => 
      array (
        0 => 'trečiadienis',
        1 => 'tr',
      ),
      'friday' => 
      array (
        0 => 'penktadienis',
        1 => 'pn',
      ),
      'thursday' => 
      array (
        0 => 'ketvirtadienis',
        1 => 'kt',
      ),
      'saturday' => 
      array (
        0 => 'šeštadienis',
        1 => 'št',
      ),
    ),
  ),
);