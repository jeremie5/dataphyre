<?php
 $date_locale=array (
  'da' => 
  array (
    'abstract' => 
    array (
      'today' => 'i dag',
      'yesterday' => 'i går',
      'two days ago' => 'for to dage siden',
      'in two days' => 'om to dage',
      'last week' => 'sidste uge',
      'last month' => 'sidste måned',
      'last year' => 'sidste år',
      'last decade' => 'sidste årti',
      'last century' => 'sidste århundrede',
      'last millennial' => 'sidste årtusinde',
      'at' => 'på',
      'of' => 'af',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'januar',
        1 => 'jan.',
      ),
      'february' => 
      array (
        0 => 'februar',
        1 => 'feb.',
      ),
      'march' => 
      array (
        0 => 'marts',
        1 => 'mar.',
      ),
      'april' => 
      array (
        0 => 'april',
        1 => 'apr.',
      ),
      'may' => 
      array (
        0 => 'maj',
        1 => 'maj',
      ),
      'june' => 
      array (
        0 => 'juni',
        1 => 'jun.',
      ),
      'july' => 
      array (
        0 => 'juli',
        1 => 'jul.',
      ),
      'august' => 
      array (
        0 => 'august',
        1 => 'aug.',
      ),
      'september' => 
      array (
        0 => 'september',
        1 => 'sep.',
      ),
      'october' => 
      array (
        0 => 'oktober',
        1 => 'okt.',
      ),
      'november' => 
      array (
        0 => 'november',
        1 => 'nov.',
      ),
      'december' => 
      array (
        0 => 'december',
        1 => 'dec.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'søndag',
        1 => 'søn.',
      ),
      'monday' => 
      array (
        0 => 'mandag',
        1 => 'man.',
      ),
      'tuesday' => 
      array (
        0 => 'tirsdag',
        1 => 'tir.',
      ),
      'wednesday' => 
      array (
        0 => 'onsdag',
        1 => 'ons.',
      ),
      'friday' => 
      array (
        0 => 'fredag',
        1 => 'fre.',
      ),
      'thursday' => 
      array (
        0 => 'torsdag',
        1 => 'tor.',
      ),
      'saturday' => 
      array (
        0 => 'lørdag',
        1 => 'lør.',
      ),
    ),
  ),
);