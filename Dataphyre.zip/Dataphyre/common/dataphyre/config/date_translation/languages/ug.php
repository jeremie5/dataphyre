<?php
 $date_locale=array (
  'ug' => 
  array (
    'abstract' => 
    array (
      'today' => 'بۈگۈن',
      'yesterday' => 'تۈنۈگۈن',
      'two days ago' => 'ئىككى كۈن ئىلگىرى',
      'in two days' => 'ئىككى كۈندە',
      'last week' => 'ئالدىنقى ھەپتە',
      'last month' => 'ئالدىنقى ئاي',
      'last year' => 'ئۆتكەن يىلى',
      'last decade' => 'ئۆتكەن ئون يىلدا',
      'last century' => 'ئالدىنقى ئەسىر',
      'last millennial' => 'ئالدىنقى مىڭ يىل',
      'at' => 'at',
      'of' => 'of',
      'am' => 'چۈشتىن بۇرۇن',
      'pm' => 'چۈشتىن كېيىن',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'يانۋار',
        1 => 'يانۋار',
      ),
      'february' => 
      array (
        0 => 'فېۋرال',
        1 => 'فېۋرال',
      ),
      'march' => 
      array (
        0 => 'مارت',
        1 => 'مارت',
      ),
      'april' => 
      array (
        0 => 'ئاپرېل',
        1 => 'ئاپرېل',
      ),
      'may' => 
      array (
        0 => 'ماي',
        1 => 'ماي',
      ),
      'june' => 
      array (
        0 => 'ئىيۇن',
        1 => 'ئىيۇن',
      ),
      'july' => 
      array (
        0 => 'ئىيۇل',
        1 => 'ئىيۇل',
      ),
      'august' => 
      array (
        0 => 'ئاۋغۇست',
        1 => 'ئاۋغۇست',
      ),
      'september' => 
      array (
        0 => 'سېنتەبىر',
        1 => 'سېنتەبىر',
      ),
      'october' => 
      array (
        0 => 'ئۆكتەبىر',
        1 => 'ئۆكتەبىر',
      ),
      'november' => 
      array (
        0 => 'نويابىر',
        1 => 'نويابىر',
      ),
      'december' => 
      array (
        0 => 'دېكابىر',
        1 => 'دېكابىر',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'يەكشەنبە',
        1 => 'يە',
      ),
      'monday' => 
      array (
        0 => 'دۈشەنبە',
        1 => 'دۈ',
      ),
      'tuesday' => 
      array (
        0 => 'سەيشەنبە',
        1 => 'سە',
      ),
      'wednesday' => 
      array (
        0 => 'چارشەنبە',
        1 => 'چا',
      ),
      'friday' => 
      array (
        0 => 'جۈمە',
        1 => 'جۈ',
      ),
      'thursday' => 
      array (
        0 => 'پەيشەنبە',
        1 => 'پە',
      ),
      'saturday' => 
      array (
        0 => 'شەنبە',
        1 => 'شە',
      ),
    ),
  ),
);