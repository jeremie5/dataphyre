<?php
 $date_locale=array (
  'pl' => 
  array (
    'abstract' => 
    array (
      'today' => 'dziś',
      'yesterday' => 'wczoraj',
      'two days ago' => 'dwa dni temu',
      'in two days' => 'za dwa dni',
      'last week' => 'zeszły tydzień',
      'last month' => 'w zeszłym miesiącu',
      'last year' => 'ostatni rok',
      'last decade' => 'ostatnia dekada',
      'last century' => 'ostatni wiek',
      'last millennial' => 'ostatnie milenium',
      'at' => 'w',
      'of' => 'z',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'stycznia',
        1 => 'sty',
      ),
      'february' => 
      array (
        0 => 'lutego',
        1 => 'lut',
      ),
      'march' => 
      array (
        0 => 'marca',
        1 => 'mar',
      ),
      'april' => 
      array (
        0 => 'kwietnia',
        1 => 'kwi',
      ),
      'may' => 
      array (
        0 => 'maja',
        1 => 'maj',
      ),
      'june' => 
      array (
        0 => 'czerwca',
        1 => 'cze',
      ),
      'july' => 
      array (
        0 => 'lipca',
        1 => 'lip',
      ),
      'august' => 
      array (
        0 => 'sierpnia',
        1 => 'sie',
      ),
      'september' => 
      array (
        0 => 'września',
        1 => 'wrz',
      ),
      'october' => 
      array (
        0 => 'października',
        1 => 'paź',
      ),
      'november' => 
      array (
        0 => 'listopada',
        1 => 'lis',
      ),
      'december' => 
      array (
        0 => 'grudnia',
        1 => 'gru',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'niedziela',
        1 => 'niedz.',
      ),
      'monday' => 
      array (
        0 => 'poniedziałek',
        1 => 'pon.',
      ),
      'tuesday' => 
      array (
        0 => 'wtorek',
        1 => 'wt.',
      ),
      'wednesday' => 
      array (
        0 => 'środa',
        1 => 'śr.',
      ),
      'friday' => 
      array (
        0 => 'piątek',
        1 => 'pt.',
      ),
      'thursday' => 
      array (
        0 => 'czwartek',
        1 => 'czw.',
      ),
      'saturday' => 
      array (
        0 => 'sobota',
        1 => 'sob.',
      ),
    ),
  ),
);