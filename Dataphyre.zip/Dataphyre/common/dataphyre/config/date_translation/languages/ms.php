<?php
 $date_locale=array (
  'ms' => 
  array (
    'abstract' => 
    array (
      'today' => 'hari ini',
      'yesterday' => 'semalam',
      'two days ago' => 'dua hari yang lalu',
      'in two days' => 'dalam dua hari',
      'last week' => 'minggu lepas',
      'last month' => 'bulan lepas',
      'last year' => 'tahun lepas',
      'last decade' => 'dekad lepas',
      'last century' => 'abad yang lalu',
      'last millennial' => 'milenium terakhir',
      'at' => 'di',
      'of' => 'daripada',
      'am' => 'PG',
      'pm' => 'PTG',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'Januari',
        1 => 'Jan',
      ),
      'february' => 
      array (
        0 => 'Februari',
        1 => 'Feb',
      ),
      'march' => 
      array (
        0 => 'Mac',
        1 => 'Mac',
      ),
      'april' => 
      array (
        0 => 'April',
        1 => 'Apr',
      ),
      'may' => 
      array (
        0 => 'Mei',
        1 => 'Mei',
      ),
      'june' => 
      array (
        0 => 'Jun',
        1 => 'Jun',
      ),
      'july' => 
      array (
        0 => 'Julai',
        1 => 'Jul',
      ),
      'august' => 
      array (
        0 => 'Ogos',
        1 => 'Ogo',
      ),
      'september' => 
      array (
        0 => 'September',
        1 => 'Sep',
      ),
      'october' => 
      array (
        0 => 'Oktober',
        1 => 'Okt',
      ),
      'november' => 
      array (
        0 => 'November',
        1 => 'Nov',
      ),
      'december' => 
      array (
        0 => 'Disember',
        1 => 'Dis',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'Ahad',
        1 => 'Ahd',
      ),
      'monday' => 
      array (
        0 => 'Isnin',
        1 => 'Isn',
      ),
      'tuesday' => 
      array (
        0 => 'Selasa',
        1 => 'Sel',
      ),
      'wednesday' => 
      array (
        0 => 'Rabu',
        1 => 'Rab',
      ),
      'friday' => 
      array (
        0 => 'Jumaat',
        1 => 'Jum',
      ),
      'thursday' => 
      array (
        0 => 'Khamis',
        1 => 'Kha',
      ),
      'saturday' => 
      array (
        0 => 'Sabtu',
        1 => 'Sab',
      ),
    ),
  ),
);