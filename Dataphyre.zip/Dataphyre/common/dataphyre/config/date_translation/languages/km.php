<?php
 $date_locale=array (
  'km' => 
  array (
    'abstract' => 
    array (
      'today' => 'ថ្ងៃនេះ',
      'yesterday' => 'ម្សិលមិញ',
      'two days ago' => 'ពីរ​ថ្ងៃមុន',
      'in two days' => 'ក្នុងរយៈពេលពីរថ្ងៃ',
      'last week' => 'សប្ដាហ៍​មុន',
      'last month' => 'ខែមុន',
      'last year' => 'ឆ្នាំមុន',
      'last decade' => 'ទសវត្សរ៍ចុងក្រោយ',
      'last century' => 'សតវត្សទីចុងក្រោយ',
      'last millennial' => 'សហស្សវត្សរ៍ចុងក្រោយ',
      'at' => 'នៅ',
      'of' => 'នៃ',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'មករា',
        1 => 'មករា',
      ),
      'february' => 
      array (
        0 => 'កុម្ភៈ',
        1 => 'កុម្ភៈ',
      ),
      'march' => 
      array (
        0 => 'មីនា',
        1 => 'មីនា',
      ),
      'april' => 
      array (
        0 => 'មេសា',
        1 => 'មេសា',
      ),
      'may' => 
      array (
        0 => 'ឧសភា',
        1 => 'ឧសភា',
      ),
      'june' => 
      array (
        0 => 'មិថុនា',
        1 => 'មិថុនា',
      ),
      'july' => 
      array (
        0 => 'កក្កដា',
        1 => 'កក្កដា',
      ),
      'august' => 
      array (
        0 => 'សីហា',
        1 => 'សីហា',
      ),
      'september' => 
      array (
        0 => 'កញ្ញា',
        1 => 'កញ្ញា',
      ),
      'october' => 
      array (
        0 => 'តុលា',
        1 => 'តុលា',
      ),
      'november' => 
      array (
        0 => 'វិច្ឆិកា',
        1 => 'វិច្ឆិកា',
      ),
      'december' => 
      array (
        0 => 'ធ្នូ',
        1 => 'ធ្នូ',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'អាទិត្យ',
        1 => 'អាទិត្យ',
      ),
      'monday' => 
      array (
        0 => 'ច័ន្ទ',
        1 => 'ច័ន្ទ',
      ),
      'tuesday' => 
      array (
        0 => 'អង្គារ',
        1 => 'អង្គារ',
      ),
      'wednesday' => 
      array (
        0 => 'ពុធ',
        1 => 'ពុធ',
      ),
      'friday' => 
      array (
        0 => 'សុក្រ',
        1 => 'សុក្រ',
      ),
      'thursday' => 
      array (
        0 => 'ព្រហស្បតិ៍',
        1 => 'ព្រហស្បតិ៍',
      ),
      'saturday' => 
      array (
        0 => 'សៅរ៍',
        1 => 'សៅរ៍',
      ),
    ),
  ),
);