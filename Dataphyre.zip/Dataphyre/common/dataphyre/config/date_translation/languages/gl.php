<?php
 $date_locale=array (
  'gl' => 
  array (
    'abstract' => 
    array (
      'today' => 'hoxe',
      'yesterday' => 'onte',
      'two days ago' => 'hai dous días',
      'in two days' => 'en dous días',
      'last week' => 'a semana pasada',
      'last month' => 'último mes',
      'last year' => 'o ano pasado',
      'last decade' => 'década pasada',
      'last century' => 'século pasado',
      'last millennial' => 'último milenio',
      'at' => 'ás',
      'of' => 'de',
      'am' => 'a.m.',
      'pm' => 'p.m.',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'xaneiro',
        1 => 'xan.',
      ),
      'february' => 
      array (
        0 => 'febreiro',
        1 => 'feb.',
      ),
      'march' => 
      array (
        0 => 'marzo',
        1 => 'mar.',
      ),
      'april' => 
      array (
        0 => 'abril',
        1 => 'abr.',
      ),
      'may' => 
      array (
        0 => 'maio',
        1 => 'maio',
      ),
      'june' => 
      array (
        0 => 'xuño',
        1 => 'xuño',
      ),
      'july' => 
      array (
        0 => 'xullo',
        1 => 'xul.',
      ),
      'august' => 
      array (
        0 => 'agosto',
        1 => 'ago.',
      ),
      'september' => 
      array (
        0 => 'setembro',
        1 => 'set.',
      ),
      'october' => 
      array (
        0 => 'outubro',
        1 => 'out.',
      ),
      'november' => 
      array (
        0 => 'novembro',
        1 => 'nov.',
      ),
      'december' => 
      array (
        0 => 'decembro',
        1 => 'dec.',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'domingo',
        1 => 'dom.',
      ),
      'monday' => 
      array (
        0 => 'luns',
        1 => 'luns',
      ),
      'tuesday' => 
      array (
        0 => 'martes',
        1 => 'mar.',
      ),
      'wednesday' => 
      array (
        0 => 'mércores',
        1 => 'mér.',
      ),
      'friday' => 
      array (
        0 => 'venres',
        1 => 'ven.',
      ),
      'thursday' => 
      array (
        0 => 'xoves',
        1 => 'xov.',
      ),
      'saturday' => 
      array (
        0 => 'sábado',
        1 => 'sáb.',
      ),
    ),
  ),
);