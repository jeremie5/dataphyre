<?php
 $date_locale=array (
  'be' => 
  array (
    'abstract' => 
    array (
      'today' => 'сёння',
      'yesterday' => 'учора',
      'two days ago' => 'два дні таму',
      'in two days' => 'праз два дні',
      'last week' => 'на мінулым тыдні',
      'last month' => 'апошні месяц',
      'last year' => 'мінулы год',
      'last decade' => 'апошняе дзесяцігоддзе',
      'last century' => 'мінулага стагоддзя',
      'last millennial' => 'апошняе тысячагоддзе',
      'at' => 'у',
      'of' => 'з',
      'am' => 'AM',
      'pm' => 'PM',
    ),
    'months' => 
    array (
      'january' => 
      array (
        0 => 'студзеня',
        1 => 'сту',
      ),
      'february' => 
      array (
        0 => 'лютага',
        1 => 'лют',
      ),
      'march' => 
      array (
        0 => 'сакавіка',
        1 => 'сак',
      ),
      'april' => 
      array (
        0 => 'красавіка',
        1 => 'кра',
      ),
      'may' => 
      array (
        0 => 'мая',
        1 => 'мая',
      ),
      'june' => 
      array (
        0 => 'чэрвеня',
        1 => 'чэр',
      ),
      'july' => 
      array (
        0 => 'ліпеня',
        1 => 'ліп',
      ),
      'august' => 
      array (
        0 => 'жніўня',
        1 => 'жні',
      ),
      'september' => 
      array (
        0 => 'верасня',
        1 => 'вер',
      ),
      'october' => 
      array (
        0 => 'кастрычніка',
        1 => 'кас',
      ),
      'november' => 
      array (
        0 => 'лістапада',
        1 => 'ліс',
      ),
      'december' => 
      array (
        0 => 'снежня',
        1 => 'сне',
      ),
    ),
    'weekdays' => 
    array (
      'sunday' => 
      array (
        0 => 'нядзеля',
        1 => 'нд',
      ),
      'monday' => 
      array (
        0 => 'панядзелак',
        1 => 'пн',
      ),
      'tuesday' => 
      array (
        0 => 'аўторак',
        1 => 'аў',
      ),
      'wednesday' => 
      array (
        0 => 'серада',
        1 => 'ср',
      ),
      'friday' => 
      array (
        0 => 'пятніца',
        1 => 'пт',
      ),
      'thursday' => 
      array (
        0 => 'чацвер',
        1 => 'чц',
      ),
      'saturday' => 
      array (
        0 => 'субота',
        1 => 'сб',
      ),
    ),
  ),
);