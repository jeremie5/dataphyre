<?php
/*************************************************************************
*  Shopiro Ltd.
*  All Rights Reserved.
* 
* NOTICE:  All information contained herein is, and remains the 
* property of Shopiro Ltd. and its suppliers, if any. The 
* intellectual and technical concepts contained herein are 
* proprietary to Shopiro Ltd. and its suppliers and may be 
* covered by Canadian and Foreign Patents, patents in process, and 
* are protected by trade secret or copyright law. Dissemination of 
* this information or reproduction of this material is strictly 
* forbidden unless prior written permission is obtained from Shopiro Ltd..
*/

try{
	include(__DIR__."/rootpaths.php");
}catch(\Throwable $exception){
	pre_init_error('Fatal error: Unable to load rootpaths', $exception);
}

try{
	include($rootpath['common_dataphyre']."modules/routing/routing.main.php");
}catch(\Throwable $exception){
	pre_init_error('Fatal error: Unable to load routing module', $exception);
}